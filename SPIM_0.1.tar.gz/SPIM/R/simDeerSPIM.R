
simDeerSPIM <-
  function(N=120,lam0.scat=0.1,lam0.cam=0.1,sigma=c(0.5,0.75),
           K=10,X1=X1,X2=X2,buff=3,ncat=ncat,pID=pID,gamma=gamma,IDcovs=IDcovs,
           ncamID=10){
    
    #simulate IDcovs
    G.true=matrix(NA,nrow=N,ncol=ncat) #all IDcovs in population.
    for(i in 1:N){
      for(j in 1:ncat){
        G.true[i,j]=sample(IDcovs[[j]],1,prob=gamma[[j]])
      }
    }
    # simulate a population of activity centers
    s<- cbind(runif(N, min(X[,1])-buff,max(X[,1])+buff), runif(N,min(X[,2])-buff,max(X[,2])+buff))
    D1<- e2dist(s,X1)
    D2<- e2dist(s,X2)
    lamd.scat<- lam0.scat*exp(-D1*D1/(2*sigma[G.true[,1]]^2))
    lamd.cam<- lam0.cam*exp(-D2*D2/(2*sigma[G.true[,1]]^2))
    J<- nrow(X)
    
    # Capture individuals
    y.scat=y.cam=array(0,dim=c(N,J,K))
    for(i in 1:N){
      for(j in 1:J){
        for(k in 1:K){
          y.scat[i,j,k]=rpois(1,lamd.scat[i,j])
          y.cam[i,j,k]=rpois(1,lamd.cam[i,j])
        }
      }
    }
    #IDs linking data sets
    ID.scat=ID.cam=1:N
    
    #remove uncaptured individuals from scat data
    scatrem=which(rowSums(y.scat)==0)
    y.scat=y.scat[-scatrem,,]
    G.true.scat=G.true[-scatrem,]
    ID.scat=ID.scat[-scatrem]
    
    #separate marked from unmarked in cams
    AMcaught=which(G.true[,1]==1&G.true[,2]==1&rowSums(y.cam)>0)
    if(length(AMcaught)<ncamID){
      warning(paste("only",length(AMcaught),"adult males caught on cameras"))
      ncamID=length(AMcaught)
    }
    AMchoose=sample(AMcaught,ncamID)
    y.cam.ID=y.cam[AMchoose,,]
    y.cam.UM=y.cam[-AMchoose,,]
    G.true.cam.ID=G.true[AMchoose,]
    G.true.cam.UM=G.true[-AMchoose,]
    ID.cam.ID=ID.cam[AMchoose]
    ID.cam.UM=ID.cam[-AMchoose]
    
    #discard identities of unmarked camera data
    remcam=which(rowSums(y.cam.UM)==0)
    y.cam.UM=y.cam.UM[-remcam,,]
    ID.cam.UM=ID.cam.UM[-remcam]
    n.samples=sum(y.cam.UM)

    G.cam.UM=matrix(NA,nrow=n.samples,ncol=ncat)
    idx=1
    A=array(0,dim=c(dim(y.cam.UM),n.samples))  #configuration matrix: indicator matrix for which individual i occassion j  trap k corresponds to sample l. used to convert corrupt IDcovs to corrupt capture history
    for(i in 1:length(ID.cam.UM)){ #loop through inds (uncaptured already removed)
      for(j in 1:J){ #then traps
        for(k in 1:K){ #then occasions
          if(y.cam.UM[i,j,k]>0){ #is there at least one sample here?
            for(l in 1:y.cam.UM[i,j,k]){ #then samples
              G.cam.UM[idx,]=G.true.cam.UM[i,]
              A[i,j,k,idx]=1
              idx=idx+1
            }
          }
        }
      }
    }
    
    
    y.cam.UM.noID=aperm(apply(A,c(2,3,4),sum),c(3,1,2))
    ID.cam.UM.noID=rep(ID.cam.UM,times=rowSums(y.cam.UM))
    
    
    #Amplification failure
    G.drop=G.cam.UM #n.samples x ncat
    for(j in 1:ncat){
      G.drop[which(rbinom(n.samples,1,pID[j])==0),j]=0 #0 is dropout
    }
   
    #reconstruct data set to be sure it was disaggregated correctly
    ycheck=array(0,dim=dim(y.cam.UM))
    for(i in 1:n.samples){
      idx2=which(A[,,,i]>0,arr.ind=TRUE)
      ycheck[idx2[1],,]=ycheck[idx2[1],,]+A[idx2[1],,,i]
    }
    if(!all(ycheck==y.cam.UM)){
      stop("not all y==ycheck")
    }
    
    #Make ID constraint matrix
    constraints=matrix(1,nrow=n.samples,ncol=n.samples)
    for(i in 1:n.samples){
      for(j in 1:n.samples){
        guys1=which(G.drop[i,]!=0)
        guys2=which(G.drop[j,]!=0)
        comp=guys1[which(guys1%in%guys2)]
        if(any(G.drop[i,comp]!=G.drop[j,comp])){
          constraints[i,j]=0
        }
      }
    }
    #check constraints
    a=which(constraints==1,arr.ind=TRUE)#consistent
    for(i in 1:nrow(a)){
      comp=G.drop[a[i,1],]>0&G.drop[a[i,2],]>0
      if(!all(G.drop[a[i,1],comp]==G.drop[a[i,2],comp])){
        stop("Error in constraint matrix")
      }
    }
    a=which(constraints==0,arr.ind=TRUE)#inconsistent
    if(length(a)>1){
      for(i in 1:nrow(a)){
        comp=G.drop[a[i,1],]>0&G.drop[a[i,2],]>0
        if(all(G.drop[a[i,1],comp]==G.drop[a[i,2],comp])){
          stop("Error in constraint matrix")
        }
      }
    }
    
    out<-list(y.scat=y.scat,y.cam=y.cam,y.cam.ID=y.cam.ID,y.cam.UM=y.cam.UM,y.cam.UM.noID=y.cam.UM.noID,
              G.true=G.true,G.true.scat=G.true.scat,G.true.cam.ID=G.true.cam.ID,G.cam.obs=G.drop,
              IDlist=list(ncat=ncat,IDcovs=IDcovs),X1=X1,X2=X2,
              K=K,buff=buff,constraints=constraints,s=s,
              ID.scat=ID.scat,ID.cam.ID=ID.cam.ID,ID.cam.UM.noID=ID.cam.UM.noID)
    return(out)
  }