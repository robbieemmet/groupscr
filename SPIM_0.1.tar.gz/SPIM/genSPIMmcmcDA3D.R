genSPIMmcmc <-
  function(data,niter=2400,nburn=1200, nthin=5, M = 200,K=NA, inits=NA,obstype="bernoulli",
           proppars=list(lam0=0.05,sigma=0.1,theta_c_c=0.1,sx=0.2,sy=0.2),keepACs=TRUE,
           nswap=10){
    library(abind)
    y.complete=y.true=data$y.complete
    y.partial<-data$y.partial.data
    X<-as.matrix(data$X)  
    J<-nrow(X)
    n.complete<- dim(y.complete)[1]
    n.partial= dim(y.partial)[1]
    n.free=M-n.complete
    K=data$K
    constraints=data$constraints
    #test this later
    if(obstype=="bernoulli"&(n.partial>0)){#add constraints that create y_ijk>1
      caps=which(y.unk==1,arr.ind=TRUE)
      for(i in 1:nrow(caps)){
        for(j in 1:nrow(caps)){
          if(i==j)break
          if(all(caps[i,2:3]==caps[j,2:3])){
            constraints[i,j]=0
            constraints[j,i]=0
          }
        }
      }
    }
    #data checks
    if(length(dim(y.complete))!=3){
      stop("dim(y.complete) must be 3 even if no guys captured")
    }
    if(nswap>n.partial){
      warning("nswap is larger than number of partial ID guys. Setting nswap=nrow(y.unk)")
      nswap=nrow(y.partial)
    }
    if(n.partial>0){
      if(n.partial!=nrow(constraints)){
        stop("data$y.partial must have same number of rows as data$constraints")
      }
      if(nrow(constraints)!=ncol(constraints)){
        stop("identity constraint matrix needs to be symmetric")
      }
    }
    
    #If using polygon state space
    if("vertices"%in%names(data)){
      vertices=data$vertices
      useverts=TRUE
      xlim=c(min(vertices[,1]),max(vertices[,1]))
      ylim=c(min(vertices[,2]),max(vertices[,2]))
    }else if("buff"%in%names(data)){
      buff<- data$buff
      xlim<- c(min(X[,1]),max(X[,1]))+c(-buff, buff)
      ylim<- c(min(X[,2]),max(X[,2]))+c(-buff, buff)
      vertices=cbind(xlim,ylim)
      useverts=FALSE
    }else{
      stop("user must supply either 'buff' or 'vertices' in data object")
    }
    ##pull out initial values
    psi<- inits$psi
    lam0<- inits$lam0
    sigma<- inits$sigma
    theta_c=inits$theta_c

    #Augment data and make initial complete data set
    if(length(dim(y.true))!=3){
      y.true<- abind(y.true,array(0, dim=c( M-dim(y.true)[1],J, K)), along=1)
    }else if(dim(y)[1]>0){
      y.true<- abind(y.true,array(0, dim=c( M-dim(y.true)[1],J, K)), along=1)
    }else{
      y.true<- array(0,dim=c(M,J,K))
    }

    if(n.partial>0){
      ##match up unknown but constrained samples to true z's
      ##for each partial, check to see if another assigned partial at same trap and can match with 
      ##all other samples matched with this partial. if >1, pick first one
      ID=rep(NA,n.partial)
      idx=n.complete+1
      y.true.tmp=y.true
      y.true.tmp[1:n.complete,,]=0
      for(i in 1:n.partial){
        traps=which(rowSums(y.partial[i,,])>0)
        y.true.tmp2D=apply(y.true.tmp,c(1,2),sum)
        if(length(traps)==1){
          cand=which(y.true.tmp2D[,traps]>0)#guys caught at same traps
        }else{
          cand=which(rowSums(y.true.tmp2D[,traps])>0)#guys caught at same traps
        }
        if(length(cand)>0){
          if(length(cand)>1){#if more than 1 ID to match to, choose first one
            cand=cand[1]
          }
          #Check constraint matrix
          cands=which(ID%in%cand)#everyone assigned this ID
          if(all(constraints[i,cands]==1)){#focal consistent with all partials already assigned
            y.true.tmp[cand,,]=y.true.tmp[cand,,]+y.partial[i,,]
            ID[i]=cand
          }else{#focal not consistent
            y.true.tmp[idx,,]=y.partial[i,,]
            ID[i]=idx
            idx=idx+1
          }
        }else{#no assigned samples at this trap
          y.true.tmp[idx,,]=y.partial[i,,]
          ID[i]=idx
          idx=idx+1
        }
      }
      #Check assignment consistency with constraints
      checkID=unique(ID)
      for(i in 1:length(checkID)){
        idx=which(ID==checkID[i])
        if(!all(constraints[idx,idx]==1)){
          stop("ID initialized improperly")
        }
      }
      ## Split into clusters (called y.partial.true in sim script)
      y.clust <- array(0L, c(n.free, J, K, maxC))
      c <- matrix(0L, n.free, maxC)  ## Binary cluster indicator
      c[,1] <- 1
      cluster <- integer(n.partial)
      for(i in 1:n.partial) {
        y.true[ID[i],,] =y.true[ID[i],,]+y.partial[i,,]
      }
      uniqueID=unique(ID)
      for(i in 1:length(uniqueID)){
        IDs=which(ID==uniqueID[i])
        nID=sum(ID==uniqueID[i])
        for(i2 in 1:nID){
          y.clust[uniqueID[i]-n.complete,,,i2]=y.partial[IDs[i2],,]
          cluster[IDs[i2]]=i2
        }
      }
      for(i in 1:n.free){
        c[i,1:min(sum(y.true[i+n.complete,,]),maxC)] <- 1
      }
      C <- rowSums(c)    ## nClusters per individual, including 0 clusters
      nDets <- rowSums(y.true[(n.complete+1):M,,])
      ## Zero-truncated binomial
      dtbin <- function(x, N, p) {
           if(x<1) {
               warning("x was 0")
               return(0)
           }
        if(N<1) {
          if(x==1)
            return(1)
          else {
            return(0)
          }
        }
        if(x>N)
          return(0)
        X0 <- 0:N
        B0 <- dbinom(X0, N, p)
        Bm1 <- B0[-1]
        BT <- Bm1/sum(Bm1)
        return(BT[x])
      }
      ll.C=rep(0,n.free)
      ll.y.clust=rep(0,n.free)
      # collapse y.true to 2D
      y.true2D=apply(y.true,c(1,2),sum)
      # collapse y.clust to 3D
      y.clust3D=apply(y.clust,c(1,2,4),sum)
      for(i in 1:n.free){
        if(nDets[i]>0){
          ll.C[i] <- log(dtbin(C[i], nDets[i], theta_c))
        }
        
        # full M x J x K x maxC data
        # for(j in 1:J) {
        #   if(all(y.true[i+n.complete,j,]<1))
        #     next
        #   for(k in 1:K) {
        #     if(y.true[i+n.complete,j,k]<1)
        #       next
        #     ll.y.clust[i] <- ll.y.clust[i]+dmultinom(y.clust[i,j,k,], y.true[i+n.complete,j,k], c[i,], log=TRUE)
        #   }
        # }
        # M x J x maxC data
        for(j in 1:J) {
          if(all(y.true[i+n.complete,j,]<1))
            next
            ll.y.clust[i] <- ll.y.clust[i]+dmultinom(y.clust3D[i,j,], y.true2D[i+n.complete,j], c[i,], log=TRUE)
          }
      }
      ll.C.cand=ll.C
    }
    #Collapse data sets to 2D
    y.complete2D=apply(y.complete,c(1,2),sum)
    y.true2D=apply(y.true,c(1,2),sum)
    y.partial2D=apply(y.partial,c(1,2),sum)
    
    #initialize z
    z=1*(apply(y.true,1,sum)>0)
    z[sample(which(z==0),sum(z==0)/2)]=1 #switch some uncaptured z's to 1.  1/3 is arbitrary. smarter way?
    if(n.partial>0){
      known.vector=c(rep(1,max(ID)),rep(0,M-max(ID)))
    }else{
      known.vector=c(rep(1,n),rep(0,M-n))
    }
    
    #Optimize starting locations given where they are trapped.
    s<- cbind(runif(M,xlim[1],xlim[2]), runif(M,ylim[1],ylim[2])) #assign random locations
    idx=which(rowSums(y.true2D)>0) #switch for those actually caught
    for(i in idx){
      trps<- X[y.true2D[i,]>0,1:2]
      trps<-matrix(trps,ncol=2,byrow=FALSE)
      s[i,]<- c(mean(trps[,1]),mean(trps[,2]))
    }
    #check to make sure everyone is in polygon
    if("vertices"%in%names(data)){
      vertices=data$vertices
      useverts=TRUE
    }else{
      useverts=FALSE
    }
    if(useverts==TRUE){
      inside=rep(NA,nrow(s))
      for(i in 1:nrow(s)){
        inside[i]=inout(s[i,],vertices)
      }
      idx=which(inside==FALSE)
      if(length(idx)>0){
        for(i in 1:length(idx)){
          while(inside[idx[i]]==FALSE){
            s[idx[i],]=c(runif(1,xlim[1],xlim[2]), runif(1,ylim[1],ylim[2]))
            inside[idx[i]]=inout(s[idx[i],],vertices)
          }
        }
      }
    }
    
    # some objects to hold the MCMC simulation output
    nstore=(niter-nburn)/nthin
    if(nburn%%nthin!=0){
      nstore=nstore+1
    }
    out<-matrix(NA,nrow=nstore,ncol=5)
    dimnames(out)<-list(NULL,c("lam0","sigma","N","clusters","theta_c_c"))
    sxout<- syout<- zout<-matrix(NA,nrow=nstore,ncol=M)
    IDout=matrix(NA,nrow=nstore,ncol=length(ID))
    idx=1 #for storing output not recorded every iteration
    
    #initialize observation model
    D<- e2dist(s, X)
    lamd=lamd.cand=lam0*exp(-D*D/(2*sigma*sigma))

    if(obstype=="bernoulli"){
      pd=pd.cand=1-exp(-lamd)
      ll.y=ll.y.cand= dbinom(y.true,K,pd*z,log=TRUE)
    }else{
      ll.y=ll.y.cand= dpois(y.true,K*lamd*z,log=TRUE)
    }
   
    ########################################    
    
    for(iter in 1:niter){
      #Update lam0
      if(obstype=="bernoulli"){
        llysum=sum(ll.y)
        lam0.cand<- rnorm(1,lam0,proppars$lam0)
        if(lam0.cand > 0){
          lamd.cand<- lam0.cand*exp(-D*D/(2*sigma*sigma))
          pd.cand=1-exp(-lamd.cand)
          ll.y.cand= dbinom(y.true,K,pd.cand*z,log=TRUE)
          llycandsum=sum(ll.y.cand)
          if(runif(1) < exp(llycandsum-llysum)){
            lam0<- lam0.cand
            lamd=lamd.cand
            pd=pd.cand
            ll.y=ll.y.cand
            llysum=llycandsum
          }
        }
        #Update sigma
        sigma.cand<- rnorm(1,sigma,proppars$sigma)
        if(sigma.cand > 0){
          lamd.cand<- lam0*exp(-D*D/(2*sigma.cand*sigma.cand))
          pd.cand=1-exp(-lamd.cand)
          ll.y.cand= dbinom(y.true,K,pd.cand*z,log=TRUE)
          llycandsum=sum(ll.y.cand)
          if(runif(1) < exp(llycandsum-llysum)){
            sigma<- sigma.cand
            lamd=lamd.cand
            pd=pd.cand
            ll.y=ll.y.cand
          }
        }
      }else{#poisson
        #Update lam0
        llysum=sum(ll.y)
        lam0.cand<- rnorm(1,lam0,proppars$lam0)
        if(lam0.cand > 0){
          lamd.cand<- lam0.cand*exp(-D*D/(2*sigma*sigma))
          ll.y.cand= dpois(y.true,K*lamd.cand*z,log=TRUE)
          llycandsum=sum(ll.y.cand)
          if(runif(1) < exp(llycandsum-llysum)){
            lam0<- lam0.cand
            lamd=lamd.cand
            ll.y=ll.y.cand
            llysum=llycandsum
          }
        }
        # Update sigma
        sigma.cand<- rnorm(1,sigma,proppars$sigma)
        if(sigma.cand > 0){
          lamd.cand<- lam0*exp(-D*D/(2*sigma.cand*sigma.cand))
          ll.y.cand= dpois(y.true,K*lamd.cand*z,log=TRUE)
          llycandsum=sum(ll.y.cand)
          if(runif(1) < exp(llycandsum-llysum)){
            sigma<- sigma.cand
            lamd=lamd.cand
            ll.y=ll.y.cand
          }
        }
      }
      
      ## Update theta_c
      theta_c.cand <- rnorm(1, theta_c, proppars$theta_c)
      ll.C.cand=ll.C
      if(theta_c.cand>0 & theta_c.cand<1) {
        for(i in 1:n.free) {
          if(nDets[i]<1)
            next
          ll.C.cand[i] <- log(dtbin(C[i], nDets[i], theta_c.cand))
        }
        if(runif(1) < exp(sum(ll.C.cand) - sum(ll.C))) {
          theta_c <- theta_c.cand
          ll.C <- ll.C.cand
        }
      }
      
      ## Update C
      c.cand <- matrix(0L, M, maxC)
      for(i in 1:n.free) {
        C.cand <- C[i] + ifelse(runif(1)<0.5, 1, -1)
        if((C.cand<1) || (C.cand>nDets[i]) || (C.cand>maxC))
          next
        c.cand[i,1:C.cand] <- 1L
        ll.C.cand[i] <- log(dtbin(C.cand, nDets[i], theta_c))
        ll.y.clust.cand[i]=0
        # for(j in 1:J) {
        #   if(all(y.true[i+n.complete,j,]<1))
        #     next
        #   for(k in 1:K) {
        #     if(y.true[i+n.complete,j,k]<1)
        #       next
        #     ll.y.clust.cand[i] <- ll.y.clust.cand[i]+dmultinom(y.clust[i,j,k,], y.true[i+n.complete,j,k],c.cand[i,], log=TRUE)
        #   }
        # }
        for(j in 1:J) {
          if(all(y.true[i+n.complete,j,]<1))
            next
            ll.y.clust.cand[i] <- ll.y.clust.cand[i]+dmultinom(y.clust3D[i,j,], y.true2D[i+n.complete,j],c.cand[i,], log=TRUE)
        }
        prop.curr <- 0
        prop.cand <- 0
        if(runif(1) < exp((ll.C.cand[i] + ll.y.clust.cand[i] + prop.cand) -
                          (ll.C[i] + ll.y.clust[i] + prop.curr) )) {
          C[i] <- C.cand
          c[i,] <- c.cand[i,]
          ll.C[i]=ll.C.cand[i]
        }
      }
      ## Update y-clust (and hence y)
      ## This draws from [y-clust|y-partials,C]
      ## Instead of trying to propose y-clust from some standard distribution,
      ##    pick it from one of the observed y-partials data. This
      ##    guarantees that [y-partials|y-clust]=1 b/c it meets the
      ##    constraints.
      
      yUps <- 0
      # ll.y.clust <- ll.y.clust.cand <- numeric(L)
      dss <- as.matrix(dist(s[(n.complete+1):M,]))  ## Distance b/w activity centers
      ppick <- apply(dss, 1, function(x) {
        pi0 <- exp(-proppars$IDdist*x) ## Used to compute proposal probs
        return(pi0)
      })
      for(l in 1:n.partial) {
        cfree <- c*z[(n.complete+1):M]  ## Which clusters are free?
        for(ll in (1:n.partial)) {
          ## Can't use a cluster position that's already taken
          cfree[ID[ll]-n.complete,cluster[ll]] <- 0
        }
        ##add constraint matrix check here
        ###
        ID.curr <- ID[l]-n.complete #ID.curr is indexed w/o y.complete guys
        cluster.curr <- cluster[l]
        pfree0 <- cfree*ppick[ID.curr,]
        pfree <- pfree0 / sum(pfree0)
        plocs <- which(pfree > 0) ## Possible places where y.partial[l] could go
        if(length(plocs)<1)
          next
        pfree.probs <- pfree[plocs]
        loc.cand <- plocs[which(rmultinom(1, 1, pfree.probs)==1)] ## asymmetric
        ID.cand <- row(c)[loc.cand]
        cluster.cand <- col(c)[loc.cand]
        IDvec.cand <- ID
        IDvec.cand[l] <- ID.cand
        clustervec.cand <- cluster
        clustervec.cand[l] <- cluster.cand
        cfree.back <- c*z  ## Which clusters are free (going back)?
        for(ll in (1:n.partial)) {
          ## Can't use a cluster position that's already taken
          cfree.back[IDvec.cand[ll],clustervec.cand[ll]] <- 0
        }
        ##add constraint matrix check here
        ###
        pfree0.back <- cfree.back*ppick[ID.cand,]
        pfree.back <- pfree0.back / sum(pfree0.back)
        ll2curr <- log(pfree.back[ID.curr,cluster.curr]) ## Pr(curr|cand)
        ll2cand <- log(pfree[ID.cand,cluster.cand]) ## Pr(cand|curr)
        y.cand <- y.true
        y.clust.cand <- y.clust
        nDets.cand <- nDets
        #subtract off y.partial[l,,] from old ID and add on y.partial[l,,] to new ID
        #Can you change clusters for same ID?
        y.clust.cand[ID.curr,,,cluster.curr] <- y.clust[ID.curr,,,cluster.curr] -
          y.partial[l,,]
        y.clust.cand[ID.cand,,,cluster.cand] <- y.clust[ID.cand,,,cluster.cand] +
          y.partial[l,,]
        if(ID.curr != ID.cand) {
          y.cand[ID.curr+n.complete,,] <- y.true[ID.curr+n.complete,,]-y.partial[l,,]
          y.cand[ID.cand+n.complete,,] <- y.true[ID.cand+n.complete,,]+y.partial[l,,]
        }
        nDets.cand[ID.curr] <- sum(y.cand[ID.curr+n.complete,,])
        nDets.cand[ID.cand] <- sum(y.cand[ID.cand+n.complete,,])
        ll.C.cand[ID.curr] <- log(dtbin(C[ID.curr], nDets.cand[ID.curr], theta_c))
        ll.C.cand[ID.cand]=  log(dtbin(C[ID.cand], nDets.cand[ID.cand], theta_c))
        ## Could speed up next stuff by monitoring ll (Should rename as ll.y)
        ## Monitoring this would require changing the way ll is
        ## defined elsewhere
        swapped=c(ID.curr,ID.cand)
        if(obstype=="poisson") {
          ll.y.cand[swapped+n.complete,,] <- dpois(y.cand[swapped+n.complete,,],
                                                       lamd[swapped+n.complete,]*z[swapped+n.complete], log=TRUE)
        } else if(obstype=="bernoulli") {
          llcand <- dbinom(y.cand[swapped+n.complete,,], 1, lam[swapped+n.complete,]*z[swapped+n.complete], log=TRUE)
        }
       ll.y.clust.cand[l] <- 0
        for(j in 1:J) {        ## Skip j and/or k loops when nDets=0?
          ## Could speed this up by skipping y=0 cases
          for(k in 1:K) {
            ll.y.clust[l] <- ll.y.clust[l] +
              dmultinom(y.clust[ID.curr,j,k,], y[ID.curr,j,k],
                        c[ID.curr,], log=TRUE) +
              dmultinom(y.clust[ID.cand,j,k,], y[ID.cand,j,k],
                        c[ID.cand,], log=TRUE)
            ll.y.clust.cand[l] <- ll.y.clust.cand[l] +
              dmultinom(y.clust.cand[ID.curr,j,k,], y.cand[ID.curr,j,k],
                        c[ID.curr,], log=TRUE) +
              dmultinom(y.clust.cand[ID.cand,j,k,], y.cand[ID.cand,j,k],
                        c[ID.cand,], log=TRUE)
          }
        }
        if(runif(1) < exp((sum(ll.y.cand[swapped+n.complete,,]) + ll.y.clust.cand[l] + ll.C.cand[swapped] + ll2curr) -
                          (sum(ll.y[swapped+n.complete,,]) + ll.y.clust[l] + ll.C[swapped] + ll2cand))) {
          ID[l] <- ID.cand+n.complete
          cluster[l] <- cluster.cand
          y.true[swapped+n.complete,,] <- y.cand[swapped+n.complete,,]
          y.clust <- y.clust.cand
          nDets[swapped] <- nDets.cand[swapped]
          yUps <- yUps+1
        }
      }
      #not needed?
      nDets <- rowSums(y.true)

      
      
      
      #update z
      ## probability of not being captured in a trap AT ALL
      if(obstype=="poisson"){
        pd=1-exp(-lamd)
      }
      pbar=(1-pd)^K
      prob0<- exp(rowSums(log(pbar)))
      fc<- prob0*psi/(prob0*psi + 1-psi)
      z[known.vector==0]<- rbinom(sum(known.vector ==0), 1, fc[known.vector==0])
      if(obstype=="bernoulli"){
        ll.y= dbinom(y.true,K,pd*z,log=TRUE)
      }else{
        ll.y= dpois(y.true,K*lamd*z,log=TRUE)
      }

      psi=rbeta(1,1+sum(z),1+M-sum(z))
   
      ## Now we have to update the activity centers
      for (i in 1:M) {
        Scand <- c(rnorm(1, s[i, 1], proppars$sx), rnorm(1, s[i, 2], proppars$sy))
        if(useverts==FALSE){
          inbox <- Scand[1] < xlim[2] & Scand[1] > xlim[1] & Scand[2] < ylim[2] & Scand[2] > ylim[1]
        }else{
          inbox=inout(Scand,vertices)
        }
        if (inbox) {
          dtmp <- sqrt((Scand[1] - X[, 1])^2 + (Scand[2] - X[, 2])^2)
          lamd.cand[i,]<- lam0*exp(-dtmp*dtmp/(2*sigma*sigma))
          if(obstype=="bernoulli"){
            pd.cand[i,]=1-exp(-lamd.cand[i,])
            ll.y.cand[i,]= dbinom(y.true[i,],K,pd.cand[i,]*z[i],log=TRUE)
            if (runif(1) < exp(sum(ll.y.cand[i,]) - sum(ll.y[i,]))) {
              s[i,]=Scand
              D[i,]=dtmp
              lamd[i,]=lamd.cand[i,]
              pd[i,]=pd.cand[i,]
              ll.y[i,]=ll.y.cand[i,]
            }
          }else{#poisson
            ll.y.cand[i,]= dpois(y.true[i,],K*lamd.cand[i,]*z[i],log=TRUE)
            if (runif(1) < exp(sum(ll.y.cand[i,]) - sum(ll.y[i,]))) {
              s[i,]=Scand
              D[i,]=dtmp
              lamd[i,]=lamd.cand[i,]
              ll.y[i,]=ll.y.cand[i,]
            }
          }
        }
      }
      #Do we record output on this iteration?
      if(iter>nburn&iter%%nthin==0){
        sxout[idx,]<- s[,1]
        syout[idx,]<- s[,2]
        zout[idx,]<- z
        if(IDupdate=="Gibbs"){
          if(Gibbs!="RC"){
            IDout[idx,]=ID
          }
        }else{
          IDout[idx,]=ID
        }
        out[idx,]<- c(lam0,sigma ,sum(z),length(unique(ID)),theta_c)
        # print(out[idx,])
        idx=idx+1
      }
    }  # end of MCMC algorithm

    if(keepACs==TRUE){
      list(out=out, sxout=sxout, syout=syout, zout=zout,IDout=IDout)
    }else{ 
      list(out=out)
    }
  }
