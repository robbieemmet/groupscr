

rtbin <- function(n, N, p) {
    if(N==0)
        return(1)
    X0 <- 0:N
    TB0 <- dbinom(X0, N, p)[-1]
    TB <- TB0/sum(TB0)
    sample(1:N, size=n, replace=TRUE, prob=TB)
}

rtbin(3, 9, 0.3)

rtbin(1, 0, 0.3)

table(rtbin(100, 9, 0.3))


simdat <- function(N, lambda0, sigma,
                   theta, maxClusters,
                   K, X, xlim, ylim) {

    J <- nrow(X)
    s <- cbind(runif(N, xlim[1], xlim[2]),
               runif(N, ylim[1], ylim[2]))

    d <- matrix(NA, N, J)
    for(i in 1:N) {
        d[i,] <- sqrt((s[i,1] - X[,1])^2 + (s[i,2] - X[,2])^2)
    }

    lambda <- matrix(NA, N, J)
    y.true <- array(NA, dim=c(N, J, K))
    y.partial.true <- array(0L, dim=c(N, J, K, maxClusters))
    y.partial.data.list <- list()

    detected <- logical(N)
    nDets <- integer(N)
    C <- rep(1L, N)

    for(i in 1:N) {
        for(j in 1:J) {
            # Expected number of encounters of ind i at location j
            lambda[i,j] <- lambda0*exp(-d[i,j]^2/(2*sigma^2))
            # Actual encounters on each occasion.
            y.true[i,j,] <- rpois(K, lambda[i,j])
        }
    }

    ## Binary cluster indicator
    c <- matrix(0L, N, maxClusters)

    det.ctr <- 1
    id <- integer(0)
    for(i in 1:N) {
        y.true.i <- y.true[i,,]
        C[i] <- rtbin(1, sum(y.true.i), theta) ## nClusters
        if(C[i] >= maxClusters)
            warnings("theta is too high relative to maxClusters")
        c[i,1:C[i]] <- 1
        for(j in 1:J) {
            for(k in 1:K) {
                if(y.true.i[j,k]<1)
                    next
                y.partial.true[i,j,k,] <- rmultinom(1, y.true.i[j,k], c[i,])
            }
        }
        for(l in 1:maxClusters) {
            if(all(y.partial.true[i,,,l]<1))
                next
            y.partial.data.list[[det.ctr]] <- y.partial.true[i,,,l]
            id[det.ctr] <- i
            det.ctr <- det.ctr+1
        }
    }

    clusterCounts <- apply(y.partial.true, c(1,4), sum)
    nDets <- rowSums(y.true)

    L <- length(y.partial.data.list)
    y.partial.data <- array(NA, c(L, J, K))
    for(l in 1:L) {
        y.partial.data[l,,] <- y.partial.data.list[[l]]
    }

    return(list(y.true=y.true,
                y.partial.true=y.partial.true,
                y.partial.data=y.partial.data,
                id=id, c=c,
                clusterCounts=clusterCounts, nClusters=C,
                nDets=nDets,
                N=N, J=J, K=K, L=L,
                X=X, xlim=xlim, ylim=ylim,
                s=s, lambda0=lambda0, sigma=sigma, theta=theta, N=N))
}



## Simulate a dataset
coor0 <- seq(0.2, 0.8, length=7)
X <- cbind(rep(coor0, each=length(coor0)),
           rep(coor0, times=length(coor0)))


##set.seed(99438)
dat1 <- simdat(N=50, lambda0=0.5, sigma=0.07,
               theta=0.5, maxClusters=10,
               K=5, X=X, xlim=c(0,1), ylim=c(0,1))

str(dat1)


## Should all be equal
sum(dat1$y.true)
sum(dat1$y.partial.true)
sum(dat1$y.partial.data)
sum(dat1$clusterCounts)
sum(dat1$nDets)

table(dat1$id)

dat1$clusterCounts ## Leading and interior zeros are allowed
sum(colSums(dat1$clusterCounts)>0)
max(dat1$nClusters)

dat1$c

dat1$nDets

## Spatial recaps
rowSums(apply(dat1$y.true, c(1,2), sum)>0)







source("uncertainSPIM-mcmc.R")


y.partials=dat1$y.partial.data
X=dat1$X
M=100
niters=1000
maxC=10
obsmod="pois"
xlims=dat1$xlim
ylims=dat1$ylim
tune=c(0.006, 0.11, .01, 15, 0.05)

##debugonce(spim)

system.time({
out1 <- spim(dat1$y.partial.data, ##dat1$y.true,
             X=dat1$X, M=100, niters=1000, maxC=10,
             obsmod="pois",
             xlims=dat1$xlim, ylims=dat1$ylim,
             tune=c(0.006, 0.11, .01, 15, 0.05))
})

library(coda)

mc1 <- mcmc(out1$samples)

plot(mc1, ask=TRUE)

mc1nb <- window(mc1, start=11)

rejectionRate(mc1nb)
effectiveSize(mc1nb)/niter(mc1nb)

summary(mc1nb)

c(sigma=dat1$sigma, lam0=dat1$lambda0, theta=dat1$theta, N=dat1$N)

out1$last$c
out1$last$C



plot(function(x) exp(-10*x), ylim=0:1)






## Parallel


library(parallel)

cl <- makeCluster(3)

source("uncertainSPIM-mcmc.R")

clusterExport(cl, c("spim", "dat1", "dtbin"))

## clusterSetRNGStream(cl, iseed=3489)

system.time({
out1p <- clusterEvalQ(cl, {
    spim(dat1$y.partial.data, ##dat1$y.true,
         X=dat1$X, M=100, niters=5000, maxC=10,
         obsmod="pois",
         xlims=dat1$xlim, ylims=dat1$ylim,
         tune=c(0.006, 0.11, .12, 0.3, 0.15))
})
})

mc1p <- mcmc.list(lapply(out1p, function(x) mcmc(x$samples)))

plot(mc1p, ask=TRUE)

mc1pp <- window(mc1p, start=1001)

rejectionRate(mc1pp)
effectiveSize(mc1pp)/niter(mc1pp)

summary(mc1pp)

stopCluster(cl)


summary(mc1p)
