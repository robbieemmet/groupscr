////////////////////////////////////in polygon functions/////////////////////
//[[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
using namespace Rcpp;
using namespace arma;
bool intersectCppgenSPIM(NumericVector sx, NumericVector sy,NumericVector vertex1, NumericVector vertex2) {
  NumericVector swap;
  double m_blue;
  double m_red;
  bool out;
  if((sy(0)==vertex1[1])|(sy(0)==vertex2[1])){
    sy(0)=sy(0)+0.000001;
  }
  if(vertex1[1]>vertex2[1]){
    swap=vertex1;
    vertex1=vertex2;
    vertex2=swap;
  }
  if((sy(0)<vertex1[1])|(sy(0)>vertex2[1])){
    out=FALSE;
  }else if((sx(0) > vertex1[0]) & (sx(0)> vertex2[0])){
    out=FALSE;
  }else{
    if((sx(0) < vertex1[0]) & (sx(0) < vertex2[0])){
      out=TRUE;
    }else{
      if(vertex1[0]!=vertex2[0]){
        m_red=(vertex2(1)-vertex1(1))/(vertex2(0)-vertex1(0));
      }else{
        m_red=1000000000000000000;
      }
      if(vertex1[0]!=sx(0)){
        m_blue=(sy(0)-vertex1(1))/(sx(0)-vertex1(0));
      }else{
        m_blue=1000000000000000000;
      }
      if(m_blue>=m_red){
        out=TRUE;
      }else{
        out=FALSE;
      }
    }
  }
  return out;
}


#include <Rcpp.h>
using namespace Rcpp;
// [[Rcpp::export]]
bool inoutgenSPIM(NumericVector sx,NumericVector sy,NumericMatrix vertices) {
  int count=0;
  int I=vertices.nrow();
  for(int i=0; i<(I-1); i++) {
    if(intersectCppgenSPIM(sx,sy,vertices(i,_),vertices(i+1,_))){
      count=count+1;
    }
  }
  bool to_return;
  if(count % 2 != 0){
    to_return = true;
  }else{
    to_return = false;
  }
  return to_return;
}

//genSPIM MCMC sampler bernoulli obs model
//[[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
using namespace Rcpp;
using namespace arma;
#include <RcppArmadilloExtensions/sample.h>
// [[Rcpp::export]]
List mcmc_genSPIMbern(double lam0, double sigma,NumericMatrix D,NumericMatrix lamd,arma::cube y,
                      arma::cube yunk,NumericMatrix X,
              IntegerVector z,NumericMatrix s, bool useverts,NumericMatrix vertices,NumericVector xlim,
              NumericVector ylim,IntegerVector knownvector,double psi,double proplam0,double propsig,
              double propsx,double propsy,int niter, int nburn, int nthin,int n,int nUnk,double swaptol,
             IntegerMatrix constraints,IntegerVector ID) {
  RNGScope scope;
  int M = size(y)[0];
  int J = size(y)[1];
  int K = size(y)[2];
  //Preallocate detection function
  double lam0cand;
  double sigmacand;
  NumericVector rand;
  NumericVector rand2;
  int clusters;
  double llysum;
  double llycandsum;
  arma::cube ll_y_curr=zeros<cube>(M,J,K);
  arma::cube ll_y_cand=zeros<cube>(M,J,K);
  NumericMatrix lamdcand(M,J);
  NumericMatrix pdcand(M,J);
  NumericMatrix pd(M,J);

  //Preallocate for Psi update
  NumericMatrix pbar(M,J);
  NumericVector prob0(M);
  NumericVector fc(M);
  int N;
  //Preallocate for ID update
  int lID = ID.size();
  int npossible;
  int ncluster1;
  int ncluster2;
  int idx;
  double sumpossible;
  double jumpprob;
  double backprob;
  NumericVector dv(M-n);
  LogicalVector possible(M-n);
  LogicalVector possible2(lID);
  LogicalVector thiscluster(lID);
  LogicalVector check(lID);
  IntegerVector newID(lID);
  arma::cube ycand=zeros<cube>(2,J,K);
  NumericVector swapped(2);

  //Preallocate for updating activity centers
  LogicalVector inbox(1);
  NumericVector dtmp(J);
  NumericVector ScandX(1);
  NumericVector ScandY(1);
  //Structures to record output
  int nstore=(niter-nburn)/nthin;
  if(nburn % nthin!=0){
    nstore=nstore+1;
  }
  NumericMatrix out(nstore,4);
  NumericMatrix sxout(nstore,M);
  NumericMatrix syout(nstore,M);
  NumericMatrix zout(nstore,M);
  NumericMatrix ID_out(nstore,lID);
  int iteridx=0;
  //////Calculate starting log likelihood///////
  //  Detection function
  for(int i=0; i<M; i++) {
    for(int j=0; j<J; j++){
      pd(i,j)=1-exp(-lamd(i,j));
      for(int k=0; k<K; k++){
        ll_y_curr(i,j,k)=z(i)*(y(i,j,k)*log(pd(i,j))+(1-y(i,j,k))*log(1-pd(i,j)));
      }
    }
  }
  //Here we go!
  for(int iter=0; iter<niter; iter++){
    /////////////////Detection function update///////////////////////
    llysum=0;
    for(int i=0; i<M; i++) {
      if(z(i)==1){
        for(int j=0; j<J; j++){
          for(int k=0; k<K; k++){
            if(ll_y_curr(i,j,k)==ll_y_curr(i,j,k)){
              llysum+=ll_y_curr(i,j,k);
            }
          }
        }
      }
    }
    //Update lam0
    rand=Rcpp::rnorm(1,lam0,proplam0);
    if(rand(0) > 0){
      llycandsum=0;
      lam0cand=rand(0);
      //  Update lamd and calculate cand likelihood
      for(int i=0; i<M; i++) {
        for(int j=0; j<J; j++){
          lamdcand(i,j)=lam0cand*exp(-D(i,j)*D(i,j)/(2*sigma*sigma));
          pdcand(i,j)=1-exp(-lamdcand(i,j));
          for(int k=0; k<K; k++){
            if(z(i)==1){
              ll_y_cand(i,j,k)=y(i,j,k)*log(pdcand(i,j))+(1-y(i,j,k))*log(1-pdcand(i,j));
              if(ll_y_cand(i,j,k)==ll_y_cand(i,j,k)){
                llycandsum+=ll_y_cand(i,j,k);
              }
            }else{
              ll_y_cand(i,j,k)=0;
            }
          }
        }
      }
      rand2=Rcpp::runif(1);
      if(rand2(0)<exp(llycandsum-llysum)){
        lam0=lam0cand;
        for(int i=0; i<M; i++) {
          for(int j=0; j<J; j++){
            lamd(i,j)=lamdcand(i,j);
            pd(i,j)=pdcand(i,j);
            for(int k=0; k<K; k++){
              ll_y_curr(i,j,k)=ll_y_cand(i,j,k);
            }
          }
        }
        llysum=llycandsum;
      }
    }
    // Update sigma
    rand=Rcpp::rnorm(1,sigma,propsig);
    if(rand(0) > 0){
      llycandsum=0;
      sigmacand=rand(0);
      //  Update lamd and calculate cand likelihood
      for(int i=0; i<M; i++) {
        for(int j=0; j<J; j++){
          lamdcand(i,j)=lam0*exp(-D(i,j)*D(i,j)/(2*sigmacand*sigmacand));
          pdcand(i,j)=1-exp(-lamdcand(i,j));
          for(int k=0; k<K; k++){
            if(z(i)==1){
              ll_y_cand(i,j,k)=y(i,j,k)*log(pdcand(i,j))+(1-y(i,j,k))*log(1-pdcand(i,j));
              if(ll_y_cand(i,j,k)==ll_y_cand(i,j,k)){
                llycandsum+=ll_y_cand(i,j,k);
              }
            }else{
              ll_y_cand(i,j,k)=0;
            }
          }
        }
      }
      rand2=Rcpp::runif(1);
      if(rand2(0)<exp(llycandsum-llysum)){
        sigma=sigmacand;
        for(int i=0; i<M; i++) {
          for(int j=0; j<J; j++){
            lamd(i,j)=lamdcand(i,j);
            pd(i,j)=pdcand(i,j);
            for(int k=0; k<K; k++){
              ll_y_curr(i,j,k)=ll_y_cand(i,j,k);
            }
          }
        }
        llysum=llycandsum;
      }
    }
    //Update IDs
    if(nUnk>0){
      for(int l=0; l<lID; l++) {
        // find who you can swap IDs to
        npossible=0;
        for(int i=0; i<(M-n); i++){
          dv(i)=pow( pow(s(ID(l),0) - s(n+i,0), 2.0) + pow(s(ID(l),1) - s(n+i,1), 2.0), 0.5 );
          if(dv(i)<swaptol){//close enough?
            if(ID(l)!=(i+n)){//not yourself? might not be right
              if(z(i+n)==1){//z==1
                possible(i)=TRUE;
                npossible+=1;
              }else{
                possible(i)=FALSE;
              }
            }else{
              possible(i)=FALSE;
            }
          }else{
            possible(i)=FALSE;
          }
        }

        if(npossible>0){//Check to see if constraints match and binomial histories are compatible
          //get indices of possible guys
          IntegerVector whopossible(npossible);
          idx=0;
          for(int i=0; i<(M-n); i++){
            if(possible(i)){
              whopossible(idx)=i+n;
              idx+=1;
            }
          }
          //find legal matches
          LogicalVector legal(npossible);
          sumpossible=0;
          for(int i2=0; i2<npossible; i2++) {//loop through possible guys
            legal(i2)=TRUE;//assume legal from start
            for(int i3=0; i3<lID; i3++) {//loop through all IDs to see who matches to this possible guy
              if(ID(i3)==(whopossible(i2))){//this guy is assigned to possible(i2)
                for(int i=0; i<lID; i++) {//find guys allocated to focal ID
                  if(ID(i)==(ID(l))){//this guy is allocated to ID(l) identity
                    //need to check this guy vs all ID guys matching possible(i2)
                    if(constraints(i,i3)==0){//test constraints
                      legal(i2)=FALSE;//false if at least one constraint
                    }
                    for(int j=0; j<J; j++) {//test if this would create y.true>1
                      for(int k=0; k<K; k++) {
                        if((yunk(i,j,k)+yunk(i3,j,k))>1){//false if at least 1
                          legal(i2)=FALSE;
                        }
                      }
                    }
                  }
                }
              }
            }
            if(legal(i2)){
              sumpossible+=1;
            }
          }
          if(sumpossible>0){//can update
            IntegerVector whopossible2(sumpossible);
            idx=0;
            for(int i=0; i<npossible; i++) {
              if(legal(i)){
                whopossible2(idx)=whopossible(i);
                idx+=1;
              }
            }
            jumpprob=1/sumpossible;
            newID=clone(ID);//memory issue?
            if(sumpossible>1){
              IntegerVector choose=Rcpp::RcppArmadillo::sample(whopossible2,1,FALSE);
              newID(l)=choose(0);
            }else{
              newID(l)=whopossible2(0);
            }
            // Rcpp::Rcout << "nID" << newID(l);
            //get backprob
            npossible=0;
            for(int i=0; i<(M-n); i++) {
              dv(i)=pow( pow(s(newID(l),0) - s(n+i,0), 2.0) + pow(s(newID(l),1) - s(n+i,1), 2.0), 0.5 );
              if(dv(i)<swaptol){//close enough?
                if(newID(l)!=(i+n)){//not yourself
                  if(z(i+n)==1){//z==1
                    possible(i)=TRUE;
                    npossible+=1;
                  }else{
                    possible(i)=FALSE;
                  }
                }else{
                  possible(i)=FALSE;
                }
              }else{
                possible(i)=FALSE;
              }
            }

            //get indices of possible guys
            IntegerVector whopossible(npossible);
            idx=0;
            for(int i=0; i<(M-n); i++) {
              if(possible(i)){
                whopossible(idx)=i+n;
                idx+=1;
              }
            }
            //find legal matches
            LogicalVector legal(npossible);
            sumpossible=0;
            for(int i2=0; i2<npossible; i2++) {//loop through possible guys
              legal(i2)=TRUE;//assume legal from start
              for(int i3=0; i3<lID; i3++) {//loop through all IDs to see who matches to this possible guy
                if(newID(i3)==(whopossible(i2))){//this guy is assigned to possible(i2)
                  for(int i=0; i<lID; i++) {//find guys allocated to focal ID
                    if(newID(i)==(newID(l))){//this guy is allocated to ID(l) identity
                      //need to check this guy vs all ID guys matching possible(i2)
                      if(constraints(i,i3)==0){//test constraints
                        legal(i2)=FALSE;//false if at least one constraint
                      }
                      for(int j=0; j<J; j++) {//test if this would create y.true>1
                        for(int k=0; k<K; k++) {
                          if(yunk(i,j,k)+yunk(i3,j,k)>1){//false if at least 1
                            legal(i2)=FALSE;
                          }
                        }
                      }
                    }
                  }
                }
              }
              if(legal(i2)){
                sumpossible+=1;
              }
            }
            backprob=1/sumpossible;
            swapped(0)=ID(l);
            swapped(1)=newID(l);
            // update y.cand
            //empty ycand
            for(int i=0; i<2; i++) {
              for(int j=0; j<J; j++) {
                for(int k=0; k<K; k++) {
                  ycand(i,j,k)=0;
                }
              }
            }
            // who is in cluster 1
            ncluster1=0;
            for(int i=0; i<lID; i++) {
              if(newID(i)==swapped(0)){
                possible2(i)=TRUE;
                ncluster1+=1;
              }else{
                possible2(i)=FALSE;
              }
            }
            if(ncluster1>0){
              IntegerVector whocluster1(ncluster1);
              idx=0;
              for(int i=0; i<lID; i++) {
                if(possible2(i)){
                  whocluster1(idx)=i;
                  idx+=1;
                }
              }
              //fill y1
              for(int i=0; i<ncluster1; i++) {
                for(int j=0; j<J; j++) {
                  for(int k=0; k<K; k++) {
                    ycand(0,j,k)+=yunk(whocluster1(i),j,k);
                  }
                }
              }
            }
            //who is in cluster 2
            ncluster2=0;
            for(int i=0; i<lID; i++) {
              if(newID(i)==swapped(1)){
                possible2(i)=TRUE;
                ncluster2+=1;
              }else{
                possible2(i)=FALSE;
              }
            }
            if(ncluster2>0){
              IntegerVector whocluster2(ncluster2);
              idx=0;
              for(int i=0; i<lID; i++) {
                if(possible2(i)){
                  whocluster2(idx)=i;
                  idx+=1;
                }
              }
              //fill y2
              for(int i=0; i<ncluster2; i++) {
                for(int j=0; j<J; j++) {
                  for(int k=0; k<K; k++) {
                    ycand(1,j,k)+=yunk(whocluster2(i),j,k);
                  }
                }
              }
            }

            //calculate ll.y.cand and sum ll.y and ll.y.cand
            llysum=0;
            llycandsum=0;
            for(int i=0; i<2; i++) {
              for(int j=0; j<J; j++){
                for(int k=0; k<K; k++){
                  ll_y_cand(swapped(i),j,k)=ycand(i,j,k)*log(pd(swapped(i),j))+(1-ycand(i,j,k))*log(1-pd(swapped(i),j));
                  if(ll_y_cand(swapped(i),j,k)==ll_y_cand(swapped(i),j,k)){
                    llycandsum+=ll_y_cand(swapped(i),j,k);
                  }
                  if(ll_y_curr(swapped(i),j,k)==ll_y_curr(swapped(i),j,k)){
                    llysum+=ll_y_curr(swapped(i),j,k);
                  }
                }
              }
            }
            
            if(llycandsum!=-INFINITY){//make sure we don't have a y for pd=0
              rand=Rcpp::runif(1);
              if(rand(0)<exp(llycandsum-llysum)*(backprob/jumpprob)){
                //Update latent data
                for(int i=0; i<2; i++) {
                  for(int j=0; j<J; j++){
                    for(int k=0; k<K; k++){
                      y(swapped(i),j,k)=ycand(i,j,k);
                      ll_y_curr(swapped(i),j,k)=ll_y_cand(swapped(i),j,k);
                    }
                  }
                }
                //Update ID
                ID(l)=newID(l);
                // //Update knownvector
                if(ncluster1>0){
                  knownvector(swapped(0))=1;
                }else{
                  knownvector(swapped(0))=0;
                }
                if(ncluster2>0){
                  knownvector(swapped(1))=1;
                }else{
                  knownvector(swapped(1))=0;
                }
              }
            }
          }
        }
      }
    }
    //Update z and psi
    N=0;
    for(int i=0; i<M; i++) {
      prob0(i)=1;
      for(int j=0; j<J; j++){
        pd(i,j)=1-exp(-lamd(i,j));
        pbar(i,j)=pow(1-pd(i,j),K);
        prob0(i)*=pbar(i,j);
      }
      fc(i)=prob0(i)*psi/(prob0(i)*psi + 1-psi);
      if(knownvector(i)==0){
        rand=Rcpp::rbinom(1,1,fc(i));
        z(i)=rand(0);
        //update likelihood
        for(int j=0; j<J; j++){
          for(int k=0; k<K; k++){
            ll_y_curr(i,j,k)=z(i)*(y(i,j,k)*log(pd(i,j))+(1-y(i,j,k))*log(1-pd(i,j)));
          }
        }
      }
      N+=z(i);
    }
    rand=Rcpp::rbeta(1, 1+N, 1+M-N);
    psi=rand(0);
    
    // Update Activity Centers
    for(int i=0; i<M; i++) {
      ScandX=Rcpp::rnorm(1,s(i,0),propsx);
      ScandY=Rcpp::rnorm(1,s(i,1),propsy);
      if(useverts==FALSE){
        inbox=(ScandX<xlim(1)) & (ScandX>xlim(0)) & (ScandY<ylim(1)) & (ScandY>ylim(0));
      }else{
        inbox=inoutgenSPIM(ScandX,ScandY,vertices);
      }
      if(inbox(0)){
        llysum=0;
        llycandsum=0;
        for(int j=0; j<J; j++){
          dtmp(j)=pow( pow(ScandX(0) - X(j,0), 2.0) + pow(ScandY(0)-X(j,1), 2.0), 0.5 );
          lamdcand(i,j)=lam0*exp(-dtmp(j)*dtmp(j)/(2*sigma*sigma));
          pdcand(i,j)=1-exp(-lamdcand(i,j));
          for(int k=0; k<K; k++){
            ll_y_cand(i,j,k)=z(i)*(y(i,j,k)*log(pdcand(i,j))+(1-y(i,j,k))*log(1-pdcand(i,j)));
            if(ll_y_cand(i,j,k)==ll_y_cand(i,j,k)){
              llycandsum+=ll_y_cand(i,j,k);
            }
            if(ll_y_curr(i,j,k)==ll_y_curr(i,j,k)){
              llysum+=ll_y_curr(i,j,k);
           }
          }
        }
        rand=Rcpp::runif(1);
        if((rand(0)<exp(llycandsum-llysum))){
          s(i,0)=ScandX(0);
          s(i,1)=ScandY(0);
          for(int j=0; j<J; j++){
            D(i,j) = dtmp(j);
            lamd(i,j) = lamdcand(i,j);
            pd(i,j) = pdcand(i,j);
            for(int k=0; k<K; k++){
              ll_y_curr(i,j,k) = ll_y_cand(i,j,k);
            }
          }
        }
      }
    }
      //Record output
      if(((iter+1)>nburn)&((iter+1) % nthin==0)){
        //count clusters
        IntegerVector uniques=unique(ID);
        clusters=uniques.size();
        for(int i=0; i<M; i++){
          sxout(iteridx,i)= s(i,0);
          syout(iteridx,i)= s(i,1);
        }
        out(iteridx,0)=lam0;
        out(iteridx,1)=sigma;
        out(iteridx,2)=N;
        out(iteridx,3)=clusters;
      }
      ID_out(iteridx,_)=ID;
      iteridx=iteridx+1;
  }
  List to_return(10);
  to_return[0] = out;
  to_return[1] = sxout;
  to_return[2] = syout;
  to_return[3] = z;
  to_return[4] = ID_out;
  to_return[5] = swapped;
  to_return[6] = ycand;
  to_return[7] = ID;
  to_return[8] = jumpprob;
  to_return[9] = backprob;
  return to_return;
}

//genSPIM MCMC sampler bernoulli obs model
//[[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
using namespace Rcpp;
using namespace arma;
// #include <RcppArmadilloExtensions/sample.h>
// [[Rcpp::export]]
List mcmc_genSPIMpois(double lam0, double sigma,NumericMatrix D,NumericMatrix lamd,arma::cube y,
                      arma::cube yunk,NumericMatrix X,
                      IntegerVector z,NumericMatrix s, bool useverts,NumericMatrix vertices,NumericVector xlim,
                      NumericVector ylim,IntegerVector knownvector,double psi,double proplam0,double propsig,
                      double propsx,double propsy,int niter, int nburn, int nthin,int n,int nUnk,double swaptol,
                      IntegerMatrix constraints,IntegerVector ID) {
  RNGScope scope;
  int M = size(y)[0];
  int J = size(y)[1];
  int K = size(y)[2];
  //Preallocate detection function
  double lam0cand;
  double sigmacand;
  NumericVector rand;
  NumericVector rand2;
  int clusters;
  double llysum;
  double llycandsum;
  arma::cube ll_y_curr=zeros<cube>(M,J,K);
  arma::cube ll_y_cand=zeros<cube>(M,J,K);
  NumericMatrix lamdcand(M,J);
  NumericMatrix pd(M,J);
  
  //Preallocate for Psi update
  NumericMatrix pbar(M,J);
  NumericVector prob0(M);
  NumericVector fc(M);
  int N;
  //Preallocate for ID update
  int lID = ID.size();
  int npossible;
  int ncluster1;
  int ncluster2;
  int idx;
  double sumpossible;
  double jumpprob;
  double backprob;
  NumericVector dv(M-n);
  LogicalVector possible(M-n);
  LogicalVector possible2(lID);
  LogicalVector thiscluster(lID);
  LogicalVector check(lID);
  IntegerVector newID(lID);
  arma::cube ycand=zeros<cube>(2,J,K);
  NumericVector swapped(2);
  
  //Preallocate for updating activity centers
  LogicalVector inbox(1);
  NumericVector dtmp(J);
  NumericVector ScandX(1);
  NumericVector ScandY(1);
  //Structures to record output
  int nstore=(niter-nburn)/nthin;
  if(nburn % nthin!=0){
    nstore=nstore+1;
  }
  NumericMatrix out(nstore,4);
  NumericMatrix sxout(nstore,M);
  NumericMatrix syout(nstore,M);
  NumericMatrix zout(nstore,M);
  NumericMatrix ID_out(nstore,lID);
  int iteridx=0;
  //////Calculate starting log likelihood///////
  //  Detection function
  for(int i=0; i<M; i++) {
    for(int j=0; j<J; j++){
      for(int k=0; k<K; k++){
        ll_y_curr(i,j,k)=z(i)*(y(i,j,k)*log(lamd(i,j))-lamd(i,j));
      }
    }
  }
  //Here we go!
  for(int iter=0; iter<niter; iter++){
    /////////////////Detection function update///////////////////////
    llysum=0;
    for(int i=0; i<M; i++) {
      if(z(i)==1){
        for(int j=0; j<J; j++){
          for(int k=0; k<K; k++){
            if(ll_y_curr(i,j,k)==ll_y_curr(i,j,k)){
              llysum+=ll_y_curr(i,j,k);
            }
          }
        }
      }
    }
    //Update lam0
    rand=Rcpp::rnorm(1,lam0,proplam0);
    if(rand(0) > 0){
      llycandsum=0;
      lam0cand=rand(0);
      //  Update lamd and calculate cand likelihood
      for(int i=0; i<M; i++) {
        for(int j=0; j<J; j++){
          lamdcand(i,j)=lam0cand*exp(-D(i,j)*D(i,j)/(2*sigma*sigma));
          for(int k=0; k<K; k++){
            if(z(i)==1){
              ll_y_cand(i,j,k)=y(i,j,k)*log(lamdcand(i,j))-lamdcand(i,j);
              if(ll_y_cand(i,j,k)==ll_y_cand(i,j,k)){
                llycandsum+=ll_y_cand(i,j,k);
              }
            }else{
              ll_y_cand(i,j,k)=0;
            }
          }
        }
      }
      rand2=Rcpp::runif(1);
      if(rand2(0)<exp(llycandsum-llysum)){
        lam0=lam0cand;
        for(int i=0; i<M; i++) {
          for(int j=0; j<J; j++){
            lamd(i,j)=lamdcand(i,j);
            for(int k=0; k<K; k++){
              ll_y_curr(i,j,k)=ll_y_cand(i,j,k);
            }
          }
        }
        llysum=llycandsum;
      }
    }
    // Update sigma
    rand=Rcpp::rnorm(1,sigma,propsig);
    if(rand(0) > 0){
      llycandsum=0;
      sigmacand=rand(0);
      //  Update lamd and calculate cand likelihood
      for(int i=0; i<M; i++) {
        for(int j=0; j<J; j++){
          lamdcand(i,j)=lam0*exp(-D(i,j)*D(i,j)/(2*sigmacand*sigmacand));
          for(int k=0; k<K; k++){
            if(z(i)==1){
              ll_y_cand(i,j,k)=y(i,j,k)*log(lamdcand(i,j))-lamdcand(i,j);
              if(ll_y_cand(i,j,k)==ll_y_cand(i,j,k)){
                llycandsum+=ll_y_cand(i,j,k);
              }
            }else{
              ll_y_cand(i,j,k)=0;
            }
          }
        }
      }
      rand2=Rcpp::runif(1);
      if(rand2(0)<exp(llycandsum-llysum)){
        sigma=sigmacand;
        for(int i=0; i<M; i++) {
          for(int j=0; j<J; j++){
            lamd(i,j)=lamdcand(i,j);
            for(int k=0; k<K; k++){
              ll_y_curr(i,j,k)=ll_y_cand(i,j,k);
            }
          }
        }
        llysum=llycandsum;
      }
    }
    //Update IDs
    if(nUnk>0){
      for(int l=0; l<nUnk; l++) {
        // find who you can swap IDs to
        npossible=0;
        for(int i=0; i<(M-n); i++){
          dv(i)=pow( pow(s(ID(l),0) - s(n+i,0), 2.0) + pow(s(ID(l),1) - s(n+i,1), 2.0), 0.5 );
          if(dv(i)<swaptol){//close enough?
            if(ID(l)!=(i+n)){//not yourself? might not be right
              if(z(i+n)==1){//z==1
                possible(i)=TRUE;
                npossible+=1;
              }else{
                possible(i)=FALSE;
              }
            }else{
              possible(i)=FALSE;
            }
          }else{
            possible(i)=FALSE;
          }
        }
        if(npossible>0){//Check to see if constraints match and binomial histories are compatible
          //get indices of possible guys
          IntegerVector whopossible(npossible);
          idx=0;
          for(int i=0; i<(M-n); i++){
            if(possible(i)){
              whopossible(idx)=i+n;
              idx+=1;
            }
          }
          //find legal matches
          LogicalVector legal(npossible);
          sumpossible=0;
          for(int i2=0; i2<npossible; i2++) {//loop through possible guys
            legal(i2)=TRUE;//assume legal from start
            for(int i3=0; i3<lID; i3++) {//loop through all IDs to see who matches to this possible guy
              if(ID(i3)==(whopossible(i2))){//this guy is assigned to possible(i2)
                for(int i=0; i<lID; i++) {//find guys allocated to focal ID
                  if(ID(i)==(ID(l))){//this guy is allocated to ID(l) identity
                    //need to check this guy vs all ID guys matching possible(i2)
                    if(constraints(i,i3)==0){//test constraints
                      legal(i2)=FALSE;//false if at least one constraint
                    }
                  }
                }
              }
            }
            if(legal(i2)){
              sumpossible+=1;
            }
          }
          if(sumpossible>0){//can update
            IntegerVector whopossible2(sumpossible);
            idx=0;
            for(int i=0; i<npossible; i++) {
              if(legal(i)){
                whopossible2(idx)=whopossible(i);
                idx+=1;
              }
            }
            jumpprob=1/sumpossible;
            // Rcpp::Rcout << "who" << whopossible2;
            newID=clone(ID);//memory issue?
            if(sumpossible>1){
              IntegerVector choose=Rcpp::RcppArmadillo::sample(whopossible2,1,FALSE);
              newID(l)=choose(0);
            }else{
              newID(l)=whopossible2(0);
            }
            // Rcpp::Rcout << "nID" << newID(l);
            
            //get backprob
            npossible=0;
            for(int i=0; i<(M-n); i++) {
              dv(i)=pow( pow(s(newID(l),0) - s(n+i,0), 2.0) + pow(s(newID(l),1) - s(n+i,1), 2.0), 0.5 );
              if(dv(i)<swaptol){//close enough?
                if(newID(l)!=(i+n)){//not yourself
                  if(z(i+n)==1){//z==1
                    possible(i)=TRUE;
                    npossible+=1;
                  }else{
                    possible(i)=FALSE;
                  }
                }else{
                  possible(i)=FALSE;
                }
              }else{
                possible(i)=FALSE;
              }
            }
            //get indices of possible guys
            IntegerVector whopossible(npossible);
            idx=0;
            for(int i=0; i<(M-n); i++) {
              if(possible(i)){
                whopossible(idx)=i+n;
                idx+=1;
              }
            }
            //find legal matches
            LogicalVector legal(npossible);
            sumpossible=0;
            for(int i2=0; i2<npossible; i2++) {//loop through possible guys
              legal(i2)=TRUE;//assume legal from start
              for(int i3=0; i3<lID; i3++) {//loop through all IDs to see who matches to this possible guy
                if(newID(i3)==(whopossible(i2))){//this guy is assigned to possible(i2)
                  for(int i=0; i<lID; i++) {//find guys allocated to focal ID
                    if(newID(i)==(newID(l))){//this guy is allocated to ID(l) identity
                      //need to check this guy vs all ID guys matching possible(i2)
                      if(constraints(i,i3)==0){//test constraints
                        legal(i2)=FALSE;//false if at least one constraint
                      }
                    }
                  }
                }
              }
              if(legal(i2)){
                sumpossible+=1;
              }
            }
            backprob=1/sumpossible;
            swapped(0)=ID(l);
            swapped(1)=newID(l);
            // update y.cand
            //empty ycand
            for(int i=0; i<2; i++) {
              for(int j=0; j<J; j++) {
                for(int k=0; k<K; k++) {
                  ycand(i,j,k)=0;
                }
              }
            }
            // who is in cluster 1
            ncluster1=0;
            for(int i=0; i<lID; i++) {
              if(newID(i)==swapped(0)){
                possible2(i)=TRUE;
                ncluster1+=1;
              }else{
                possible2(i)=FALSE;
              }
            }
            if(ncluster1>0){
              IntegerVector whocluster1(ncluster1);
              idx=0;
              for(int i=0; i<lID; i++) {
                if(possible2(i)){
                  whocluster1(idx)=i;
                  idx+=1;
                }
              }
              //fill y1
              for(int i=0; i<ncluster1; i++) {
                for(int j=0; j<J; j++) {
                  for(int k=0; k<K; k++) {
                    ycand(0,j,k)+=yunk(whocluster1(i),j,k);
                  }
                }
              }
            }
            //who is in cluster 2
            ncluster2=0;
            for(int i=0; i<lID; i++) {
              if(newID(i)==swapped(1)){
                possible2(i)=TRUE;
                ncluster2+=1;
              }else{
                possible2(i)=FALSE;
              }
            }
            if(ncluster2>0){
              IntegerVector whocluster2(ncluster2);
              idx=0;
              for(int i=0; i<lID; i++) {
                if(possible2(i)){
                  whocluster2(idx)=i;
                  idx+=1;
                }
              }
              //fill y2
              for(int i=0; i<ncluster2; i++) {
                for(int j=0; j<J; j++) {
                  for(int k=0; k<K; k++) {
                    ycand(1,j,k)+=yunk(whocluster2(i),j,k);
                  }
                }
              }
            }
            
            //calculate ll.y.cand and sum ll.y and ll.y.cand
            llysum=0;
            llycandsum=0;
            for(int i=0; i<2; i++) {
              for(int j=0; j<J; j++){
                for(int k=0; k<K; k++){
                  ll_y_cand(swapped(i),j,k)=ycand(i,j,k)*log(lamd(swapped(i),j))-lamd(swapped(i),j);
                  if(ll_y_cand(swapped(i),j,k)==ll_y_cand(swapped(i),j,k)){
                    llycandsum+=ll_y_cand(swapped(i),j,k);
                  }
                  if(ll_y_curr(swapped(i),j,k)==ll_y_curr(swapped(i),j,k)){
                    llysum+=ll_y_curr(swapped(i),j,k);
                  }
                }
              }
            }
            if(llycandsum!=-INFINITY){//make sure we don't have a y for pd=0
              rand=Rcpp::runif(1);
              if(rand(0)<exp(llycandsum-llysum)*(backprob/jumpprob)){
                //Update latent data
                for(int i=0; i<2; i++) {
                  for(int j=0; j<J; j++){
                    for(int k=0; k<K; k++){
                      y(swapped(i),j,k)=ycand(i,j,k);
                      ll_y_curr(swapped(i),j,k)=ll_y_cand(swapped(i),j,k);
                    }
                  }
                }
                //Update ID
                ID(l)=newID(l);
                // //Update knownvector
                if(ncluster1>0){
                  knownvector(swapped(0))=1;
                }else{
                  knownvector(swapped(0))=0;
                }
                if(ncluster2>0){
                  knownvector(swapped(1))=1;
                }else{
                  knownvector(swapped(1))=0;
                }
              }
            }
          }
        }
      }
    }
    
    //Update z and psi
    N=0;
    for(int i=0; i<M; i++) {
      prob0(i)=1;
      for(int j=0; j<J; j++){
        pd(i,j)=1-exp(-lamd(i,j));
        pbar(i,j)=pow(1-pd(i,j),K);
        prob0(i)*=pbar(i,j);
      }
      fc(i)=prob0(i)*psi/(prob0(i)*psi + 1-psi);
      if(knownvector(i)==0){
        rand=Rcpp::rbinom(1,1,fc(i));
        z(i)=rand(0);
        for(int j=0; j<J; j++){
          for(int k=0; k<K; k++){
            ll_y_curr(i,j,k)=z(i)*(y(i,j,k)*log(lamd(i,j))-lamd(i,j));
          }
        }
      }
      N+=z(i);
    }
    rand=Rcpp::rbeta(1, 1+N, 1+M-N);
    psi=rand(0);
    
    // Now we have to update the activity centers//////////////////
    // Update Activity Centers
    for(int i=0; i<M; i++) {
      ScandX=Rcpp::rnorm(1,s(i,0),propsx);
      ScandY=Rcpp::rnorm(1,s(i,1),propsy);
      if(useverts==FALSE){
        inbox=(ScandX<xlim(1)) & (ScandX>xlim(0)) & (ScandY<ylim(1)) & (ScandY>ylim(0));
      }else{
        inbox=inoutgenSPIM(ScandX,ScandY,vertices);
      }
      if(inbox(0)){
        llysum=0;
        llycandsum=0;
        for(int j=0; j<J; j++){
          dtmp(j)=pow( pow(ScandX(0) - X(j,0), 2.0) + pow(ScandY(0)-X(j,1), 2.0), 0.5 );
          lamdcand(i,j)=lam0*exp(-dtmp(j)*dtmp(j)/(2*sigma*sigma));
          for(int k=0; k<K; k++){
            ll_y_cand(i,j,k)=z(i)*(y(i,j,k)*log(lamdcand(i,j))-lamdcand(i,j));
            if(ll_y_cand(i,j,k)==ll_y_cand(i,j,k)){
              llycandsum+=ll_y_cand(i,j,k);
            }
            if(ll_y_curr(i,j,k)==ll_y_curr(i,j,k)){
              llysum+=ll_y_curr(i,j,k);
            }
          }
        }
        rand=Rcpp::runif(1);
        if((rand(0)<exp(llycandsum-llysum))){
          s(i,0)=ScandX(0);
          s(i,1)=ScandY(0);
          for(int j=0; j<J; j++){
            D(i,j) = dtmp(j);
            lamd(i,j) = lamdcand(i,j);
            for(int k=0; k<K; k++){
              ll_y_curr(i,j,k) = ll_y_cand(i,j,k);
            }
          }
        }
      }
    }
    //Record output
    if(((iter+1)>nburn)&((iter+1) % nthin==0)){
      //count clusters
      IntegerVector uniques=unique(ID);
      clusters=uniques.size();
      for(int i=0; i<M; i++){
        sxout(iteridx,i)= s(i,0);
        syout(iteridx,i)= s(i,1);
      }
      out(iteridx,0)=lam0;
      out(iteridx,1)=sigma;
      out(iteridx,2)=N;
      out(iteridx,3)=clusters;
    }
    ID_out(iteridx,_)=ID;
    iteridx=iteridx+1;
  }
  
  List to_return(5);
  to_return[0] = out;
  to_return[1] = sxout;
  to_return[2] = syout;
  to_return[3] = z;
  to_return[4] = ID_out;
  
  return to_return;
}