library(SPIM)
storeLatent=FALSE

#Basic
N=50
lam0=0.2
sigma=0.5
K=10
buff=3
X=expand.grid(3:9,3:9)
obstype="poisson"
data=simSCR(N=N,lam0=lam0,sigma=sigma,K=K,X=X,
            buff=buff,obstype=obstype)
niter=1000
nburn=0
nthin=1
M=100
inits=list(lam0=lam0,sigma=sigma,psi=0.5)
proppars = list(lam0 = 0.05, sigma = 0.1,
                sx = 0.2, sy =0.2)
a=Sys.time()
out=mcmc.SCR(data,niter=niter,nburn=nburn,nthin=nthin,
         M=M,inits=inits,proppars=proppars,
         storeLatent = TRUE, Rcpp = TRUE)
b=Sys.time()
b-a

library(coda)
plot(mcmc(out$out))


#trap file
N=50
lam0=0.2
sigma=0.5
K=10
buff=3
X=expand.grid(3:9,3:9)
obstype="bernoulli"
data=simSCRtf(N=N,lam0=0.2,sigma=sigma,X=X,buff=3,
              failrate=0.05,faildur=2,obstype=obstype)
niter=1000
nburn=0
nthin=1
M=100
inits=list(lam0=lam0,sigma=sigma,psi=0,5)
proppars = list(lam0 = 0.05, sigma = 0.1,
                sx = 0.2, sy =0.2)
a=Sys.time()
out=mcmc.SCR(data,niter=niter,nburn=nburn,nthin=nthin,
             M=M,inits=inits,proppars=proppars,
             storeLatent = FALSE, Rcpp = TRUE)
b=Sys.time()
b-a
plot(mcmc(out$out))

