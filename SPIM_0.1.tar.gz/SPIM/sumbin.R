dsumbin <- function(x, size, prob) {
  
  m <- length(size)
  
  # Handle the case with only one binomial.
  
  if (m==1) return(dbinom(x, size, prob))
  
  # Handle the case with only two binomials.
  
  U <- rep(0, sum(size)+1)        ### Set up the final result vector now
  
  Y <- dbinom(0:size[1], size[1], prob[1])
  Z <- dbinom(0:size[2], size[2], prob[2])
  
  Y <- c(Y, rep(0, size[2]))      ### Pad Y and Z appropriately
  Z <- c(Z, rep(0, size[1]))
  
  for (j in 0:(size[1]+size[2])) {
    
    U[j+1] <- sum(Y[(0+1):(j+1)] * Z[(j+1):(0+1)])
    
  } 
  
  if (m==2) return(U[(x+1)])
  
  # Handle the remaining cases.
  
  for (k in 3:m) {
    
    Y <- U
    Z <- dbinom(0:size[k], size[k], prob[k])
    
    Z <- c(Z, rep(0, sum(size[1:(k-1)]))) ### Pad Z appropriately
    
    for (j in 0:(sum(size[1:k]))) {
      
      U[j+1] <- sum(Y[(0+1):(j+1)] * Z[(j+1):(0+1)])
      
    } 
  }
  
  return(U[(x+1)])
  
}