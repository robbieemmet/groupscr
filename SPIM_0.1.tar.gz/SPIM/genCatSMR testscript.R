#######base sampler
N=50
lam0.mark=0.05
lam0.sight=0.25
sigma=0.50
K1=10
K2=10
buff=2
X1<- expand.grid(3:11,3:11)
X2<- expand.grid(3:11+0.5,3:11+0.5)
pMarkID=c(0.8,0.8) #probability of observing marked status of marked and unmarked guys
pID=0.8
obstype=c("bernoulli","poisson")
ncat=3  #number of loci
gamma=IDcovs=vector("list",ncat) #population frequencies of each genotype. Assume equal for now
nlevels=rep(2,ncat) #number of IDcovs per loci
for(i in 1:ncat){
  gamma[[i]]=rep(1/nlevels[i],nlevels[i])
  IDcovs[[i]]=1:nlevels[i]
}
pIDcat=rep(1,ncat)#loci amplification/observation probabilities
#Example of interspersed marking and sighting. 
Korder=c("M","M","S","S","S","S","M","M","S","M","M","S","M","M","S","S","S","S","M","M")
#Example with no interspersed marking and sighting.
Korder=c(rep("M",10),rep("S",10))
tlocs=25
data=sim.genCatSMR(N=N,lam0.mark=lam0.mark,lam0.sight=lam0.sight,sigma=sigma,K1=K1,
        K2=K2,Korder=Korder,X1=X1,X2=X2,buff=buff,obstype=obstype,ncat=ncat,
           pIDcat=pIDcat,IDcovs=IDcovs,gamma=gamma,pMarkID=pMarkID,pID=pID,tlocs=tlocs)

inits=list(lam0.mark=lam0.mark,lam0.sight=lam0.sight,sigma=sigma,gamma=gamma,psi=0.7)
proppars=list(lam0.mark=0.05,lam0.sight=0.05,sigma=0.01,s=0.25,st=0.25)
M=100
storeLatent=TRUE
storeGamma=FALSE
niter=1000
nburn=0
nthin=1
IDup="Gibbs"
out=mcmc.genCatSMR(data,niter=niter,nburn=nburn, nthin=nthin, M = M, inits=inits,obstype=obstype,
           proppars=proppars,storeLatent=storeLatent,storeGamma=storeGamma,IDup=IDup)
library(coda)
plot(mcmc(out$out))
1-rejectionRate(mcmc(out$out)) #shoot for between 0.2 and 0.4 for df parameters
1-rejectionRate(mcmc(out$sxout)) #make sure none are <0.1?
length(unique(data$IDum)) #true number of unmarked individuals
y2d=apply(data$y.sight.marked,c(1,2),sum)
y12d=apply(data$y.mark,c(1,2),sum)
Xall=rbind(X1,X2)
xlim<- c(min(Xall[,1]),max(Xall[,1]))+c(-buff, buff)
ylim<- c(min(Xall[,2]),max(Xall[,2]))+c(-buff, buff)

idx=1#which individual to plot?
plot(X2,xlim=xlim,ylim=ylim,pch=4)
points(out$s1xout[,idx],out$s1yout[,idx])
points(out$s2xout[,idx],out$s2yout[,idx],col="grey")
points(data$locs[idx,,1],data$locs[idx,,2],col="red")
traps=which(y2d[idx,]>0)
points(X2[traps,1],X2[traps,2],col='blue')
traps=which(y12d[idx,]>0)
points(X1[traps,1],X1[traps,2],col='green')



###df sampler
N=100
lam0.mark=c(0.075,0.01)
lam0.sight=c(0.3,0.2)
sigma=c(0.6,0.5)
K1=10 #number of marking occasions
K2=10 #number of sighting occasions
buff=2 #state space buffer
X1<- expand.grid(3:11,3:11) #marking locations
X2<- expand.grid(3:11+0.5,3:11+0.5) #sighting locations
pMarkID=c(0.8,0.8) #probability of observing marked status of marked and unmarked individuals
pID=0.8 #probability of determining identity of marked individuals
obstype=c("bernoulli","poisson") #observation model of both processes
ncat=3  #number of categorical identity covariates
gamma=IDcovs=vector("list",ncat) 
nlevels=rep(2,ncat) #number of IDcovs per loci
for(i in 1:ncat){ 
  gamma[[i]]=rep(1/nlevels[i],nlevels[i])
  IDcovs[[i]]=1:nlevels[i]
}
#inspect ID covariates and level probabilities
str(IDcovs) #3 covariates with 2 levels
str(gamma) #each of the two levels are equally probable
pIDcat=rep(1,ncat) #category observation probabilities
#Example of interspersed marking and sighting. 
Korder=c("M","M","S","S","S","S","M","M","S","M","M","S","M","M","S","S","S","S","M","M")
#Example with no interspersed marking and sighting.
Korder=c(rep("M",10),rep("S",10))
tlocs=5
data=sim.genCatSMR.df(N=N,lam0.mark=lam0.mark,lam0.sight=lam0.sight,sigma=sigma,K1=K1,
                   K2=K2,Korder=Korder,X1=X1,X2=X2,buff=buff,obstype=obstype,ncat=ncat,
                   pIDcat=pIDcat,IDcovs=IDcovs,gamma=gamma,pMarkID=pMarkID,pID=pID,tlocs=tlocs)


inits=list(lam0.mark=lam0.mark,lam0.sight=lam0.sight,sigma=sigma,gamma=gamma,psi=0.7)
proppars=list(lam0.mark=c(0.05,0.025),lam0.sight=c(0.09,0.09),sigma=c(0.04,0.045),s=0.45,st=0.45)
M=150
storeLatent=TRUE
storeGamma=FALSE
niter=500
nburn=0
nthin=1
IDup="Gibbs"
out=mcmc.genCatSMR.df(data,niter=niter,nburn=nburn, nthin=nthin, M = M, inits=inits,obstype=obstype,
                      proppars=proppars,storeLatent=TRUE,storeGamma=TRUE,IDup=IDup)

plot(mcmc(out$out))
1-rejectionRate(mcmc(out$out))
1-rejectionRate(mcmc(out$sxout))

y2d=apply(data$y.sight.marked,c(1,2),sum)
y12d=apply(data$y.trap,c(1,2),sum)
Xall=rbind(X1,X2)
xlim<- c(min(Xall[,1]),max(Xall[,1]))+c(-buff, buff)
ylim<- c(min(Xall[,2]),max(Xall[,2]))+c(-buff, buff)

idx=1#which individual to plot?
plot(X2,xlim=xlim,ylim=ylim,pch=4)
points(out$s1xout[,idx],out$s1yout[,idx])
points(out$s2xout[,idx],out$s2yout[,idx],col="grey")
points(data$locs[idx,,1],data$locs[idx,,2],col="red")
traps=which(y2d[idx,]>0)
points(X2[traps,1],X2[traps,2],col='blue')
traps=which(y12d[idx,]>0)
points(X1[traps,1],X1[traps,2],col='green')


####move version
N=50
lam0.mark=0.05
lam0.sight=0.25
sigma_d=0.50
sigma_p=1
K1=10
K2=10
buff=2
X1<- expand.grid(3:11,3:11)
X2<- expand.grid(3:11+0.5,3:11+0.5)
pMarkID=c(0.8,0.8) #probability of observing marked status of marked and unmarked guys
pID=0.8
obstype=c("bernoulli","poisson")
ncat=3  #number of loci
gamma=IDcovs=vector("list",ncat) #population frequencies of each genotype. Assume equal for now
nlevels=rep(2,ncat) #number of IDcovs per loci
for(i in 1:ncat){
  gamma[[i]]=rep(1/nlevels[i],nlevels[i])
  IDcovs[[i]]=1:nlevels[i]
}
pIDcat=rep(1,ncat)#loci amplification/observation probabilities
tlocs=25
data=sim.genCatSMR.move(N=N,lam0.mark=lam0.mark,lam0.sight=lam0.sight,sigma_d=sigma_d,sigma_p=sigma_p,K1=K1,
                        K2=K2,X1=X1,X2=X2,buff=buff,obstype=obstype,ncat=ncat,
                        pIDcat=pIDcat,gamma=gamma,IDcovs=IDcovs,pMarkID=pMarkID,tlocs=tlocs)

inits=list(lam0.mark=lam0.mark,lam0.sight=lam0.sight,sigma_d=sigma_d,sigma_p=sigma_p,gamma=gamma,psi=0.7)
proppars=list(lam0.mark=0.05,lam0.sight=0.1,sigma_d=0.02,sigma_p=0.2,s1=0.5,s2=0.25,s2t=0.1)#poisson-poisson
M=100
storeLatent=TRUE
storeGamma=FALSE
niter=50
nburn=0
nthin=1
IDup="MH"
out=mcmc.genCatSMR.move(data,niter=niter,nburn=nburn, nthin=nthin, M = M, inits=inits,obstype=obstype,
                        proppars=proppars,storeLatent=TRUE,storeGamma=TRUE,IDup=IDup)

plot(mcmc(out$out))
1-rejectionRate(mcmc(out$out))
1-rejectionRate(mcmc(out$s1xout))
1-rejectionRate(mcmc(out$s2xout))


y2d=apply(data$y.sight.marked,c(1,2),sum)
y12d=apply(data$y.trap,c(1,2),sum)

idx=idx+1#which individual to plot?
plot(X2,xlim=xlim,ylim=ylim,pch=4)
points(out$s1xout[,idx],out$s1yout[,idx])
points(out$s2xout[,idx],out$s2yout[,idx],col="grey")
points(data$locs[idx,,1],data$locs[idx,,2],col="red")
traps=which(y2d[idx,]>0)
points(X2[traps,1],X2[traps,2],col='blue')
traps=which(y12d[idx,]>0)
points(X1[traps,1],X1[traps,2],col='green')
