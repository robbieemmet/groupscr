
## Zero-truncated binomial
dtbin <- function(x, N, p) {
##    if(x<1) {
##        warning("x was 0")
##        return(0)
##    }
    if(N<1) {
        if(x==1)
            return(1)
        else {
            return(0)
        }
    }
    if(x>N)
        return(0)
    X0 <- 0:N
    B0 <- dbinom(X0, N, p)
    Bm1 <- B0[-1]
    BT <- Bm1/sum(Bm1)
    return(BT[x])
}




## SCR (SPIM) model for data consisting of clusters of partial
## detections. ie, we know that the detections within each cluster are
## from the same individuals, but we don't know which (if any) of the
## clusters match with each other.

## The joint posterior is
## [y-clust,y,C,z,s,psi,theta,lam0,sigma|y-partials] \propto
##    [y-partials|y-partials.true][y-partials.true|y,C][C|theta][y|z,s,lam0,sigma][z|psi][s][priors]

spim <- function(y.partials,
                 X, M,
                 maxC, ## maximum number of clusters
                 obsmod=c("pois", "bern"),
                 niters, xlims, ylims,
                 inits=NULL,
                 ## tune order: sigma, lam0, theta, y-clust, s
                 tune=c(0.015, 0.1, 0.14, 5, 0.15)) {

    # obsmod <- match.arg(obsmod)
    L <- nrow(y.partials)
    if(M < L)
        stop("Make M bigger")

    J <- ncol(y.partials)
    K <- dim(y.partials)[3]
    s <- cbind(runif(M, xlims[1], xlims[2]),
               runif(M, ylims[1], ylims[2]))
    sigma <- 6*runif(1, min(abs(diff(X[,1]))), max(abs(diff(X[,1]))))
    lam0 <- runif(1, 0.1, 0.5) # This is p0 when obsmod="bern"
    psi <- runif(1, 0.9, 0.99)
    theta <- runif(1)

    dist <- matrix(NA, M, J)
    for(j in 1:J) {
        dist[,j] <- sqrt((s[,1]-X[j,1])^2 + (s[,2]-X[j,2])^2)
    }
    lam <- lam0*exp(-(dist^2)/(2*sigma^2))
    ## Latent encounter histories (called y.true in sim script)
    y <- array(0L, c(M, J, K))
    ## Split into clusters (called y.partials.true in sim script)
    y.clust <- array(0L, c(M, J, K, maxC))
    c <- matrix(0L, M, maxC)  ## Binary cluster indicator
    c[,1] <- 1
    cluster <- integer(L)
    for(l in 1:nrow(y.partials)) {
        y[l,,] <- y.partials[l,,]
        y.clust[l,,,1] <- y.partials[l,,]
        cluster[l] <- 1
        c[l,1:min(sum(y[l,,]),maxC)] <- 1
    }
    C <- rowSums(c)           ## nClusters per individual
    id <- 1:L
    nDets <- rowSums(y)

    z <- ifelse(rowSums(y)>0, 1L, 0L)

    if(!all(dim(s) == c(M, 2)))
        stop("The dimensions of s should be ", c(M, 2))
    if(length(z) != M)
        stop("length(z) should be ", M)

    out <- matrix(NA, nrow=niters, ncol=6)
    nought <- ifelse(obsmod=="pois", "lam0", "p0")
    colnames(out) <- c("sigma", nought, "theta", "psi", "N", "deviance")

    cat("\nstarting values =", c(sigma, lam0, theta, psi, sum(z)), "\n\n")

    for(iter in 1:niters) {

        if(iter %% 10 == 0) {
            cat("iter", iter, format(Sys.time(), "%H:%M:%S"), "\n")
            cat("   current =", out[iter-1,], "\n")
        }

        if(obsmod=="pois") {
            ll <- sum(dpois(y, lam*z, log=TRUE))
        } else if(obsmod=="bern") {
            ll <- sum(dbinom(y, 1, lam*z, log=TRUE))
        }

        ## update sigma
        sigma.cand <- rnorm(1, sigma, tune[1])
        if(sigma.cand > 0) {
            prior <- prior.cand <- 0
            lam.cand <- lam0*exp(-(dist*dist) /
                                 (2*sigma.cand*sigma.cand))
            if(obsmod=="pois") {
                llcand <- sum(dpois(y, lam.cand*z, log=TRUE))
            } else if(obsmod=="bern") {
                llcand <- sum(dbinom(y, 1, lam.cand*z, log=TRUE))
            }
            if(runif(1) < exp((llcand + prior.cand) - (ll + prior))) {
                ll <- llcand
                lam <- lam.cand
                sigma <- sigma.cand
            }
        }

        ## update lam0
        lam0.cand <- rnorm(1, lam0, tune[2])
        lok <- TRUE
        if(obsmod=="bern")
            lok <- lam0.cand <= 1
        if((lam0.cand >= 0) & lok) {
            lam.cand <- lam0.cand*exp(-(dist*dist)/(2*sigma*sigma))
            if(obsmod=="pois") {
                llcand <- sum(dpois(y, lam.cand*z, log=TRUE))
            } else if(obsmod=="bern") {
                llcand <- sum(dbinom(y, 1, lam.cand*z, log=TRUE))
            }
            prior <- prior.cand <- 0
            if(runif(1) < exp((llcand + prior.cand) - (ll + prior))) {
                ll <- llcand
                lam0 <- lam0.cand
                lam <- lam.cand
            }
        }

        ## update z
        zUps <- 0
        nDets <- rowSums(y)
        seen <- nDets > 0 #(y>0, 1, any)
        for(i in 1:M) {
            if(seen[i])
                next
            zcand <- z
            zcand[i] <- ifelse(z[i]==0, 1, 0)
            if(obsmod=="pois") {
                ll <- sum(dpois(y[i,,], lam[i,]*z[i], log=TRUE))
                llcand <- sum(dpois(y[i,,], lam[i,]*zcand[i], log=TRUE))
            } else if(obsmod=="bern") {
                ll <- sum(dbinom(y[i,,], 1, lam[i,]*z[i], log=TRUE))
                llcand <- sum(dbinom(y[i,,], 1, lam[i,]*zcand[i], log=TRUE))
            }
            prior <- dbinom(z[i], 1, psi, log=TRUE)
            prior.cand <- dbinom(zcand[i], 1, psi, log=TRUE)
            if(runif(1) < exp( (llcand+prior.cand) - (ll+prior) )) {
                z[i] <- zcand[i]
                zUps <- zUps+1
            }
        }

        if(any(z<1 & rowSums(y)>0))
            browser()

        ## update psi
        psi <- rbeta(1, 1+sum(z), 1+M-sum(z))

        ## Update theta
        theta.cand <- rnorm(1, theta, tune[3])
        ll.C <- ll.C.cand <- numeric(M)
        if(theta.cand>0 & theta.cand<1) {
            for(i in 1:M) {
                if(nDets[i]<1)
                    next
                ll.C[i] <- log(dtbin(C[i], nDets[i], theta))
                ll.C.cand[i] <- log(dtbin(C[i], nDets[i], theta.cand))
            }
            if(runif(1) < exp(sum(ll.C.cand) - sum(ll.C))) {
                theta <- theta.cand
                ll.C <- ll.C.cand
            }
       }

        ## Update C
        c.cand <- matrix(0L, M, maxC)
        ll.y.clust <- ll.y.clust.cand <- numeric(M)
        ll.C <- ll.C.cand <- numeric(M)
        cUps <- 0
        for(i in 1:M) {
##            if(nDets[i]<1)
##                next
##            if(c[i,1]<1 & any(c[i,2:maxC]>1))
##                stop("Bad c")
            C.cand <- C[i] + ifelse(runif(1)<0.5, 1, -1)
            if((C.cand<1) || (C.cand>nDets[i]) || (C.cand>maxC))
                next
            c.cand[i,1:C.cand] <- 1L
##            if(nDets[i]>0) {
                ll.C[i] <- log(dtbin(C[i], nDets[i], theta))
                ll.C.cand[i] <- log(dtbin(C.cand, nDets[i], theta))
##            }
            ll.y.clust[i] <- ll.y.clust.cand[i] <- 0
            for(j in 1:J) {
                if(all(y[i,j,]<1))
                    next
                for(k in 1:K) {
                    if(y[i,j,k]<1)
                        next
                    ll.y.clust[i] <- ll.y.clust[i] +
                        dmultinom(y.clust[i,j,k,], y[i,j,k], c[i,], log=TRUE)
                    ll.y.clust.cand[i] <- ll.y.clust.cand[i] +
                        dmultinom(y.clust[i,j,k,], y[i,j,k],
                                  c.cand[i,], log=TRUE)
                }
            }
            # if(!is.finite(sum(ll.y.clust.cand))||!is.finite(sum(ll.C.cand)))stop("!")
            prop.curr <- 0
            prop.cand <- 0
            if(runif(1) < exp((ll.C.cand[i] + ll.y.clust.cand[i] + prop.cand) -
                              (ll.C[i] + ll.y.clust[i] + prop.curr) )) {
                C[i] <- C.cand
                c[i,] <- c.cand[i,]
                cUps <- cUps+1
            }
        }

##        }

        ## Update y-clust (and hence y)
        ## This draws from [y-clust|y-partials,C]
        ## Instead of trying to propose y-clust from some standard distribution,
        ##    pick it from one of the observed y-partials data. This
        ##    guarantees that [y-partials|y-clust]=1 b/c it meets the
        ##    constraints.

        yUps <- 0
##        if(iter>300)
##            browser()
        ll.y.clust <- ll.y.clust.cand <- numeric(L)
        dss <- as.matrix(dist(s))  ## Distance b/w activity centers
        ppick <- apply(dss, 1, function(x) {
            pi0 <- exp(-tune[4]*x) ## Used to compute proposal probs
##            pi0 <- x<tune[4] ## Only consider guys within distance of tune[4]
            return(pi0)
##            return(pi0/sum(pi0))
        })
##        diag(ppick) <- 0   ## This was a bad bug
        for(l in 1:L) {
            cfree <- c*z  ## Which clusters are free?
            for(ll in (1:L)) {
                ## Can't use a cluster position that's already taken
                cfree[id[ll],cluster[ll]] <- 0
            }
            id.curr <- id[l]
            cluster.curr <- cluster[l]
            pfree0 <- cfree*ppick[id.curr,]
            pfree <- pfree0 / sum(pfree0)
            plocs <- which(pfree > 0) ## Possible places where y.partial[l] could go
            if(length(plocs)<1)
                next
            pfree.probs <- pfree[plocs]
##            loc.cand <- plocs[sample(length(plocs),1,prob=pfree.probs)] ## asymmetric
            loc.cand <- plocs[which(rmultinom(1, 1, pfree.probs)==1)] ## asymmetric
            id.cand <- row(c)[loc.cand]
##            if(id.cand==id.curr) ## Bad. It should be possible to switch between clusters even if ID doesn't change
##                next
            cluster.cand <- col(c)[loc.cand]
            idvec.cand <- id
            idvec.cand[l] <- id.cand
            clustervec.cand <- cluster
            clustervec.cand[l] <- cluster.cand
            cfree.back <- c*z  ## Which clusters are free (going back)?
            for(ll in (1:L)) {
                ## Can't use a cluster position that's already taken
                cfree.back[idvec.cand[ll],clustervec.cand[ll]] <- 0
            }
            pfree0.back <- cfree.back*ppick[id.cand,]
            pfree.back <- pfree0.back / sum(pfree0.back)
            ll2curr <- log(pfree.back[id.curr,cluster.curr]) ## Pr(curr|cand)
            ll2cand <- log(pfree[id.cand,cluster.cand]) ## Pr(cand|curr)
            y.cand <- y
            y.clust.cand <- y.clust
            nDets.cand <- nDets
            y.clust.cand[id.curr,,,cluster.curr] <- y.clust[id.curr,,,cluster.curr] -
                y.partials[l,,]
            y.clust.cand[id.cand,,,cluster.cand] <- y.clust[id.cand,,,cluster.cand] +
                y.partials[l,,]
            if(id.curr != id.cand) {
                y.cand[id.curr,,] <- y[id.curr,,]-y.partials[l,,]
                y.cand[id.cand,,] <- y[id.cand,,]+y.partials[l,,]
            }
            nDets.cand[id.curr] <- sum(y.cand[id.curr,,])
            nDets.cand[id.cand] <- sum(y.cand[id.cand,,])
            ll.C <- log(dtbin(C[id.curr], nDets[id.curr], theta)) +
                log(dtbin(C[id.cand], nDets[id.cand], theta))
            ll.C.cand <- log(dtbin(C[id.curr], nDets.cand[id.curr], theta)) +
                log(dtbin(C[id.cand], nDets.cand[id.cand], theta))
            ## Could speed up next stuff by monitoring ll (Should rename as ll.y)
            ## Monitoring this would require changing the way ll is
            ## defined elsewhere
            if(obsmod=="pois") {
                ll <- sum(dpois(y, lam*z, log=TRUE))
                llcand <- sum(dpois(y.cand, lam*z, log=TRUE))
            } else if(obsmod=="bern") {
                ll <- sum(dbinom(y, 1, lam*z, log=TRUE))
                llcand <- sum(dbinom(y.cand, 1, lam*z, log=TRUE))
            }
            ll.y.clust[l] <- ll.y.clust.cand[l] <- 0
            for(j in 1:J) {        ## Skip j and/or k loops when nDets=0?
                ## Could speed this up by skipping y=0 cases
                for(k in 1:K) {
                    ll.y.clust[l] <- ll.y.clust[l] +
                        dmultinom(y.clust[id.curr,j,k,], y[id.curr,j,k],
                                  c[id.curr,], log=TRUE) +
                        dmultinom(y.clust[id.cand,j,k,], y[id.cand,j,k],
                                  c[id.cand,], log=TRUE)
                    ll.y.clust.cand[l] <- ll.y.clust.cand[l] +
                        dmultinom(y.clust.cand[id.curr,j,k,], y.cand[id.curr,j,k],
                                  c[id.curr,], log=TRUE) +
                        dmultinom(y.clust.cand[id.cand,j,k,], y.cand[id.cand,j,k],
                                  c[id.cand,], log=TRUE)
                }
            }
            # if(!is.finite(sum(ll.y.clust.cand))||!is.finite(sum(ll.C.cand)))stop("!!")
            if(runif(1) < exp((llcand + ll.y.clust.cand[l] + ll.C.cand + ll2curr) -
                              (ll + ll.y.clust[l] + ll.C + ll2cand))) {
                id[l] <- id.cand
                cluster[l] <- cluster.cand
                y <- y.cand
                y.clust <- y.clust.cand
                nDets <- rowSums(y)
                yUps <- yUps+1
            }

        }

        nDets <- rowSums(y)

        ## update s
        sups <- 0
        for(i in 1:M) {   # note this is "M" in general
            scand <- c(rnorm(1, s[i,1], tune[5]),
                       rnorm(1, s[i,2], tune[5]))
            inbox <- (scand[1] > xlims[1] & scand[1] < xlims[2]) &
                (scand[2] > ylims[1] & scand[2] < ylims[2])
            if(!inbox)
                next
            dtmp <- sqrt((scand[1] - X[,1])^2 +
                         (scand[2] - X[,2])^2)
            lam.cand <- lam
            lam.cand[i,] <- lam0*exp(-(dtmp*dtmp)/(2*sigma*sigma) )
            if(z[i] == 0) {
                ll <- llcand <- 0
            } else if(z[i] == 1) {
                if(obsmod=="pois") {
                    ll <- sum(dpois(y[i,,], lam[i,]*z[i], log=TRUE))
                    llcand <- sum(dpois(y[i,,], lam.cand[i,]*z[i],
                                        log=TRUE))
                } else if(obsmod=="bern") {
                    ll <- sum(dbinom(y[i,,], 1, lam[i,]*z[i], log=TRUE))
                    llcand <- sum(dbinom(y[i,,], 1, lam.cand[i,]*z[i],
                                         log=TRUE))
                }
            }
            if(runif(1) < exp(llcand - ll)) {
                ll <- llcand
                s[i,] <- scand
                lam[i,] <- lam.cand[i,]
                dist[i,] <- dtmp
                sups <- sups+z[i] # Only update for real guys
            }
        }
        deviance <- -2*sum(dpois(y, lam*z, log=TRUE))
        if(iter %% 10 == 0) {
            cat("   Acceptance rates\n")
            cat("     z =", zUps/M, "\n")
            cat("     s =", sups/sum(z), "\n")
            cat("     y =", yUps/L, "\n")
            cat("     c =", cUps/sum(z), "\n")
            cat("     cluster dist = \n")
            print(table(C))
        }
        out[iter,] <- c(sigma,lam0,theta,psi,sum(z),deviance )
    }

    last <- list(sigma=sigma, lam0=lam0, psi=psi, z=z, s=s,
                 C=C, c=c, id, cluster, y.clust=y.clust, y=y)
    ret <- list(samples=out, last=last)
    return(ret)
}


















