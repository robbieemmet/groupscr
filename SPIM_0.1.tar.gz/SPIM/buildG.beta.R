library(readxl)
data <- read_excel("C:/Users/Administrator/Desktop/BrownBear2.xlsx")
data=data.frame(data[,-1]) #lose first column


nloci=ncol(data)/2
nsamples=nrow(data)

####### Method 1 - Include all possible loci-level genotypes implied by the observed alleles
#Construct all possible loci level genotypes
genotypes=list(nloci)
idx=seq(1,ncol(data)-1,2)
for(i in 1:length(idx)){
  alleles=unique(c(unique(data[,idx[i]]),unique(data[,idx[i]+1])))
  alleles=alleles[-which(is.na(alleles))]
  genotypes[[i]]=expand.grid(alleles,alleles)
}

#
G.obs=matrix(0,nrow=nsamples,ncol=nloci)
for(i in 1:length(idx)){
  for(j in 1:nsamples){
    if(any(is.na(data[j,idx[i]:(idx[i]+1)]))) next
    G.obs[j,i]=which(data[j,idx[i]]==genotypes[[i]][,1]&data[j,idx[i]+1]==genotypes[[i]][,2])
  }
}

#make IDlist, which is an element of the data
IDlist=list()
IDlist$ncat=19
IDlist$IDcovs=lapply(genotypes,function(x){1:nrow(x)})

#Make starting values for gamma. Set them all equal.
gamma=lapply(IDlist[[2]],function(x){rep(1/length(x),length(x))})

#check that each numbered genotype at each loci is the same. one by one. Could check all, but confident
#algorithm works
checkloci=2
unique(G.obs[,checkloci]) #which genotypes were actually observed? Pick one of these for checkgeno
checkgeno=1
data[which(G.obs[,checkloci]==checkgeno),idx[checkloci]:(idx[checkloci]+1)]



##### Method 2 - Only use observed loci level genotypes
#paste 2 alleles together
genotypes=data.frame(apply(data[,1:2],1,function(x){paste(x,collapse=".")}))
idx=seq(1,ncol(data)-1,2)
for(i in 2:length(idx)){
  genotypes=cbind(genotypes,apply(data[,idx[i]:(idx[i]+1)],1,function(x){paste(x,collapse=".")}))
}
#Name genotypes
loci=colnames(data)[idx]
colnames(genotypes)=loci
#convert missing data to NA
genotypes[genotypes=="NA.NA"]=NA

#Convert genotypes to G.obs
G.obs=matrix(0,nrow=nsamples,ncol=nloci)
uniques=list(nloci)
for(j in 1:nloci){
  uniques[[j]]=unique(genotypes[,j])
  rem=which(is.na(uniques[[j]]))
  if(length(rem)>0){
    uniques[[j]]=uniques[[j]][-rem]
  }
  for(i in 1:nsamples){
    if(!is.na(genotypes[i,j])){
      G.obs[i,j]=which(uniques[[j]]==genotypes[i,j])
    }else{
      G.obs[i,j]=0 #missing genotypes coded as 0
    }
  }
}

#make IDlist, which is an element of the data
IDlist=list()
IDlist$ncat=19
IDlist$IDcovs=lapply(uniques,function(x){1:length(x)})

#Make starting values for gamma. Set them all equal.
gamma=lapply(IDlist[[2]],function(x){rep(1/length(x),length(x))})

#check that each numbered genotype at each loci is the same. one by one. Could check all, but confident
#algorithm works
checkloci=3
checkgeno=5
genotypes[which(G.obs[,1]==checkgeno),checkloci]
