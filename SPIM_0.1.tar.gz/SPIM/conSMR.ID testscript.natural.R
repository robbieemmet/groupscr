source("sim.conCatSMR.ID.R")
# source("mcmc.conSMR.natural.ID.R")
source("mcmc.conCatSMR.ID.R")
library(coda)
N=50
n.marked=12
lam0=0.35
sigma=0.50
K=10
buff=3
X<- expand.grid(3:11,3:11)
# pMarkID=c(0.5,0.5) #probability of observing marked status of marked and unmarked guys
pMarkID=c(.8,.8)
pID=.8
ncat=3  #number of loci
gamma=genotypes=vector("list",ncat) #population frequencies of each genotype. Assume equal for now
nlevels=rep(2,ncat) #number of genotypes per loci
for(i in 1:ncat){
  gamma[[i]]=rep(1/nlevels[i],nlevels[i])
  genotypes[[i]]=1:nlevels[i]
}
pAmp=rep(1,ncat)#loci amplification/observation probabilities
tlocs=0
obstype="poisson"
marktype="premarked"
data=sim.conCatSMR.ID(N=N,n.marked=n.marked,lam0=lam0,sigma=sigma,K=K,X=X,buff=buff,obstype=obstype,ncat=ncat,
           pAmp=pAmp,gamma=gamma,genotypes=genotypes,pMarkID=pMarkID,tlocs=tlocs,pID=pID,marktype=marktype)

inits=list(lam0=lam0,sigma=sigma,gamma=gamma,psi=0.5)
proppars=list(lam0=0.05,sigma=0.01,s=0.75,st=0.12)#telemetry
proppars=list(lam0=0.1,sigma=0.08,s=0.75,st=0.08)
M=150
keepACs=FALSE
keepGamma=FALSE
niter=1000
nburn=0
nthin=1
IDup="Gibbs"
out=mcmc.conCatSMR.ID(data,niter=niter,nburn=nburn, nthin=nthin, M = M, inits=inits,obstype=obstype,
           proppars=proppars,keepACs=TRUE,keepGamma=TRUE,IDup=IDup)


plot(mcmc(out$out))



1-rejectionRate(mcmc(out$s1xout))
1-rejectionRate(mcmc(out$s2xout))
1-rejectionRate(mcmc(out$out))
tail(out$out[,4],20)
sum(rowSums(data$y.sight[(n.marked+1):N,,])>0)

idx=1
idx=idx+1
unique(out$IDout[,idx,1])
unique(out$IDout[,idx,2])
