library(coda)
setwd("E:/Google Drive/SPIM (1)/SPIM/R")
source("simgenSPIMv2.R")
N=30
p0=0.35
lam0=-log(1-p0)   
sigma=0.50
K=10
buff=2
xlim<- c(1,14)
ylim<- c(1,14)
X<- expand.grid(3:12,3:12)
theta_c=0.25
theta_p=0.5
theta_m=0.25
maxC=20
obstype="poisson"
# obstype="bernoulli"
data=simgenSPIM(N=N,lam0=lam0,sigma=sigma,theta_c=theta_c,theta_p=theta_p,theta_m=theta_m,
                K=K,X=X,buff=buff,obstype=obstype,maxC=maxC)
dim(data$y.partial.data)
rowSums(data$y.partial.data)


M=60
inits=list(lam0=lam0,sigma=sigma,psi=0.6,theta_c=theta_c)
niter=500
nburn=0
nthin=1
proppars=list(lam0=0.1,sigma=0.075,sx=0.5,sy=0.5,theta_c=0.15,IDdist=3)

a=Sys.time()
out=genSPIMmcmc(data,niter=niter,nburn=0,nthin=1, M = M,K=K, inits=inits,proppars=proppars,obstype=obstype)
b=Sys.time()
b-a
plot(mcmc(out$out))


apply(out$IDout,1,function(x){length(unique(x))})

#break apart across traps
J=nrow(X)
idx=which(rowSums(apply(data$yUnkobs,c(1,2),sum)>0)>1)
for(i in idx){
  traps=which(rowSums(data$yUnkobs[i,,])>0)
  for(j in 2:length(traps)){
    data$yUnkobs=abind(data$yUnkobs,matrix(0,nrow=J,ncol=K),along=1)#add 0 entry
    data$yUnkobs[nrow(data$yUnkobs),traps[j],]=data$yUnkobs[i,traps[j],]#fill in new entry
    data$yUnkobs[i,traps[j],]=rep(0,K)#empty out tra
  }
}
data$constraints=matrix(1,nrow=nrow(data$yUnkobs),ncol=nrow(data$yUnkobs))



#reconstruct yUnk
yUnk=data$yUnk
yUnkobs=data$yUnkobs
unkIDs=data$unkIDs
yUnk2=array(0,dim=dim(yUnk))
for(i in 1:length(unkIDs)){
  yUnk2[unkIDs[i],,]=yUnk2[unkIDs[i],,]+yUnkobs[i,,]
}
all(yUnk==yUnk2)

#check constraints
constraints=data$constraints
for(i in 1:length(unkIDs)){
  check=which(unkIDs==unkIDs[i])
  for(j in 1:length(check)){
    if(constraints[i,check[j]]!=1){
      print(i)
    }
  }
}




idx=19
who=out$IDout[,idx]+1
plot(X,xlim=xlim,ylim=ylim,pch=4)
# points(out$sxout[,who],out$syout[,who])
for(j in 1:(niter-nburn)){
  points(out$sxout[j,who[j]],out$syout[j,who[j]],pch=20,col=rgb(1,0,0,0.1),cex=0.1)
}
cap=which(rowSums(data$yUnkobs[idx,,])>0)
points(X[cap,1],X[cap,2],pch=4,col="red")


plot(data$X,pch=4,xlim=xlim,ylim=ylim)
points(data$s[data$s.status=="ID",1],data$s[data$s.status=="ID",2],col="green",pch=18)
points(data$s[data$s.status=="unk",1],data$s[data$s.status=="unk",2],col="red",pch=18)
points(data$s[data$s.status=="uncaptured",1],data$s[data$s.status=="uncaptured",2],col="black",pch=18)
yUnk=data$yUnk
yUnk=apply(yUnk,c(1,2),sum)
unkidx=which(data$s.status=="unk")
s=data$s
for(i in 1:nrow(yUnk)){
  traps=which(yUnk[i,]>0)
  for(j in 1:length(traps)){
    lines(c(s[unkidx[i],1],X[traps[j],1]),c(s[unkidx[i],2],X[traps[j],2]))
  }
}
who=out$IDout[,idx]
for(j in 1:(niter-nburn)){
  points(out$sxout[j,who[j]],out$syout[j,who[j]],pch=20,col=rgb(1,0,0,0.1),cex=0.1)
}
cap=which(rowSums(data$yUnkobs[idx,,])>0)
points(X[cap,1],X[cap,2],pch=4,col="red")


IDout=out$IDout[1000,]
idx=49
who=which(IDout==IDout[idx])
data$unkIDs[who]

cbind(data$unkIDs,out$IDout[1000,])

idx2=70
plot(out$sxout[,idx2],out$syout[,idx2],xlim=xlim,ylim=ylim)


