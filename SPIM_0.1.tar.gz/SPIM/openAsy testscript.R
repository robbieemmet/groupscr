# library(SPIM)
library(coda)
library(gdistance)
source("simOpenAsySCR.R")
source("SCRmcmcOpenAsy.R")
#same but t=3
t=5
N=25
p0=0.5
lam0=-log(1-p0)
sigma=0.75
sigma_t=1 #dispersal sigma
phi=0.95
gamma=0.1
X=list(expand.grid(4:9,4:9),expand.grid(4:9,4:9),expand.grid(4:9,4:9),expand.grid(4:9,4:9),expand.grid(4:9,4:9))
K=c(10,10,10,10,10)
M=60
ACtype="AD"
r.ad=0
res=4
discrete.s <- expand.grid(seq(2,13,sigma/res),seq(2,13,sigma/res))
cost <- runif(nrow(discrete.s),0,2)
cost=list(cost) #allow different cost surface in different years. same if length(cost)==1
data=simOpenAsySCR(N=N,phi=phi,gamma=gamma,lam0=lam0,sigma=sigma,sigma_t=sigma_t,K=K,X=X,t=t,M=M,
                   ACtype=ACtype,r.ad=r.ad,cost=cost,discrete.s=discrete.s)

inits=list(lam0=lam0,sigma=sigma,gamma=gamma,phi=phi,psi=N/M,sigma_t=sigma_t,r.ad=r.ad)
niter=200
nburn=0
nthin=1
proppars=list(lam0=0.06,sigma=0.02,gamma=0.15,s1x=0.05,s1y=0.05,s2x=0.2,s2y=0.2,sigma_t=1,r.ad=0.4)

a=Sys.time()
out=SCRmcmcOpenAsy(data,niter=niter,nburn=nburn, nthin=nthin, M =M, inits=inits,proppars=proppars,ACtype="AD")
b=Sys.time()
b-a
plot(mcmc(out$out))
summary(mcmc(out$out))

idx=24
jit=0.5
year=1
plot(X[[1]],xlim=c(2,11),ylim=c(2,11),pch=4)
points(jitter(out$s2xout[,idx,year],jit),jitter(out$s2yout[,idx,year],jit),pch=18)
points(data$s[idx,year,1],data$s[idx,year,2],col="red",pch=4)
apply(data$y,c(1,3),sum)[idx,]

