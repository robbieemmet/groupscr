S.np <- function(n,m){
  ## Purpose:  Stirling Numbers of the 2-nd kind
  ## 		S^{(m)}_n = number of ways of partitioning a set of
  ##                      $n$ elements into $m$ non-empty subsets
  ## Author: Martin Maechler, Date:  May 28 1992, 23:42
  ## ----------------------------------------------------------------
  ## Abramowitz/Stegun: 24,1,4 (p. 824-5 ; Table 24.4, p.835)
  ## Closed Form : p.824 "C."
  ## ----------------------------------------------------------------
  if (0 > m || m > n) stop("'m' must be in 0..n !")
  k <- 0:m
  sig <- rep(c(1,-1)*(-1)^m, length= m+1)
  ga <- gamma(k+1)
  round(sum( sig * k^n /(ga * rev(ga))))
}


k=m=2 #must be equal if all boxes are filled
n=12


Ppart=function(m,k,n){
  stop=m-k+1
  mk=prod(m:stop)
  mn=0
  for(i in 1:n){
    stop.i=m-i+1
    mk.i=prod(m:stop.i)
    mn=mn+S.np(n,i)*mk.i
  }
  mk/mn
}
Ppart(m,k,n)
1/S.np(n,k)


y.sum=4
bi=3

Ci=c(4,3,2)
factorial(y.sum)/prod(factorial(c(1,1,2)))/S.np(y.sum,3)/factorial(bi)+
  factorial(y.sum)/prod(factorial(c(1,2,1)))/S.np(y.sum,3)/factorial(bi)+
  factorial(y.sum)/prod(factorial(c(2,1,1)))/S.np(y.sum,3)/factorial(bi)
1/S.np(y.sum,bi)  
1/choose(y.sum-1,bi-1)


S.np(y.sum[2],bi)  
S.np(y.sum[2],bi)*factorial(bi)  

factorial(9)/(prod(factorial(9-Ci)))

modComp=function(y.sum,bi){
  comps=ncombs=vector("list",length(y.sum))
  for(i in 1:length(comps)){
    comps[[i]]=t(apply(t(compositions(y.sum[i],bi)),1,function(x){x>0}))
    ncombs[[i]]=1:choose(y.sum[i]+bi-1,y.sum[i])
  }
  cells=prod(choose(y.sum+bi-1,y.sum))
  store=matrix(NA,nrow=cells,ncol=length(y.sum)*bi)
  idx=expand.grid(ncombs)
  store=rep(NA,nrow(idx))
  count=0
  for(i in 1:nrow(idx)){
    a=matrix(NA,nrow=bi,ncol=ncol(idx))
    for(j in 1:ncol(idx)){
      a[,j]=comps[[j]][idx[i,j],]
    }
    if(all(rowSums(a)>0)){
      count=count+1
    }
  }
  count
}

m=c(4,1,1,5)
x1=c(2,0,0,0)
x2=c(1,1,1,1)
x3=c(1,0,0,2)
x4=m-x1-x2-x3

p1=dMFNCHypergeo(x1, m,2,odds=1)
p2=dMFNCHypergeo(x2, m-x1,sum(x2),odds=1)
p3=dMFNCHypergeo(x3, m-x1-x2,sum(x3),odds=1)
p3=dMFNCHypergeo(x4, m-x1-x2-x3,sum(x4),odds=1)

p1=dMFNCHypergeo(x3, m,5,odds=1)
p2=dMFNCHypergeo(x2, m-x3,sum(x2),odds=1)
p3=dMFNCHypergeo(x1, m-x3-x1,sum(x1),odds=1)

p1=dMFNCHypergeo(x2, m,4,odds=1)
p2=dMFNCHypergeo(x3, m-x2,sum(x3),odds=1)
p3=dMFNCHypergeo(x1, m-x3-x2,sum(x1),odds=1)


dMFNCHypergeo(m, m,sum(m),odds=1)
