#Update ID
if(nUnk>0){
  #chandler joint njk update
  # if(obstype=="poisson"){
  #   y.true=y
  #   for(j in 1:J){
  #     p1=lamd[unk.guys,j]*z[unk.guys]
  #     p2=p1/sum(p1)
  #     for(k in 1:K){
  #       if(njk[j,k]>0){
  #         deal=rmultinom(1,njk[j,k],prob=p2)
  #         guys=which(deal>0)
  #         y.true[unk.guys[guys],j,k]=deal[guys]
  #       }
  #     }
  #   }
  #   known.vector=1*(rowSums(y.true)>0)
  #   ll.y=dpois(y.true,lamd*z,log=TRUE)
  # }else{
  #   y.true=y
  #   for(j in 1:J){
  #     p1=pd[unk.guys,j]*z[unk.guys]
  #     p2=p1/sum(p1)
  #     for(k in 1:K){
  #       if(njk[j,k]>0){
  #         guys=sample(unk.guys,njk[j,k],prob=p2)
  #         y.true[guys,j,k]=1
  #       }
  #     }
  #   }
  #   known.vector=1*(rowSums(y.true)>0)
  #   ll.y=dbinom(y.true,1,pd*z,log=TRUE)
  # }
  for(l in 1:nUnk){
    if(obstype=="bernoulli"){
      #find who you can swap IDs to
      dv<-  sqrt( (s[ID[l],1]- s[(n+1):M,1])^2 + (s[ID[l],2] - s[(n+1):M,2])^2 )
      possible<- which(dv < swap.tol)+n
      possible=possible[-which(possible==ID[l])]
      possible=possible[z[possible]==1]
      if(length(possible)>0){#Check to see if constraints match and binomial histories are compatible
        thiscluster=which(ID==ID[l])
        legal=rep(TRUE,length(possible))
        #Check to see if you can swap into these clusters
        for(i in 1:length(possible)){
          check=which(ID==possible[i])#Who else is currently assigned this possible new ID?
          if(length(check)>0){#if false, no ID assigned to this guy and legal stays true
            for(k in 1:length(thiscluster)){#loop through guys in focal cluster
              for(j in 1:length(check)){#check against guys in possible cluster
                if(constraints[thiscluster[k],check[j]]==0){#if any members of the cluster are inconsistent, illegal move
                  legal[i]=FALSE
                }
                if(any(y.unk[thiscluster[k],,]+y.unk[check[j],,]>1)){#would we create a y.true=2?
                  legal[i]=FALSE
                }
              }
            }
          }
        }
        possible=possible[legal]
        if(length(possible)>0){#Can update
          jump.probability<- 1/length(possible) # h(theta*|theta)
          newID=ID
          if(length(possible)>1){
            newID[l] <-  sample( possible, 1)
          }else{
            newID[l]=possible
          }
          trash<-  sqrt( (s[newID[l],1]- s[(n+1):M,1])^2 + (s[newID[l],2] - s[(n+1):M,2])^2 )
          trash<-   which(dv < swap.tol)+n
          trash=trash[-which(trash==newID[l])]
          trash=trash[z[trash]==1]
          legal=rep(TRUE,length(trash))
          backcluster=which(newID==newID[l])#which guys are in the new ID cluster?
          # Check to see if you can swap into these clusters
          for(i in 1:length(trash)){
            check=which(newID==trash[i])
            for(k in 1:length(backcluster)){#loop through guys in back cluster
              if(length(check)>0){#if false, no ID assigned to this back guy and legal stays true
                for(j in 1:length(check)){#check against back guys in proposed cluster
                  if(constraints[backcluster[k],check[j]]==0){#if any members of the cluster are inconsistent, illegal move
                    legal[i]=FALSE
                  }
                  if(any(y.unk[backcluster[k],,]+y.unk[check[j],,]>1)){#would we create a y.true=2?
                    legal[i]=FALSE
                  }
                }
              }
            }
          }
          trash=trash[legal]
          jump.back<-  1/length(trash)
          swapped=c(ID[l],newID[l])#order swap.out then swap.in
          cluster1guys=which(newID==swapped[1])
          cluster2guys=which(newID==swapped[2])
          y.cand=array(0,dim=c(2,J,K))
          if(length(cluster1guys)>0){
            if(length(cluster1guys)>1){
              y.cand[1,,]=colSums(y.unk[cluster1guys,,])
            }else{
              y.cand[1,,]=y.unk[cluster1guys,,]
            }
          }
          if(length(cluster2guys)>0){
            if(length(cluster2guys)>1){
              y.cand[2,,]=colSums(y.unk[cluster2guys,,])
            }else{
              y.cand[2,,]=y.unk[cluster2guys,,]
            }
          }
          # Propose new S from full conditional based on new ID
          # s.cand=matrix(NA,nrow=2,ncol=2)
          # dtmp=matrix(NA,nrow=2,ncol=J)
          # lamd.cand=lamd
          # for(i in 1:2){
          #   #find mean cluster location to center window around
          #   traps=which(rowSums(y.cand[i,,])>0)
          #   if(length(traps)==0){#if empty cluster, center around current s
          #     meanS=s[swapped[i],]
          #   }else{#cluster not empty
          #     currS=X[traps,]
          #     if(!is.null(dim(currS))){#if more than one location
          #       meanS=colMeans(currS)
          #     }else{#only 1 location
          #       meanS=currS
          #     }
          #   }
          #   xlim2=c(meanS[1]-s.lim/2,meanS[1]+s.lim/2)
          #   ylim2=c(meanS[2]-s.lim/2,meanS[2]+s.lim/2)
          #   grid.locs=as.matrix(expand.grid(seq(xlim2[1],xlim2[2],res),seq(ylim2[1],ylim2[2],res)))
          #   #Check for any off state space
          #   rem=which(grid.locs[,1]<xlim[1]|grid.locs[,1]>xlim[2]|grid.locs[,2]<ylim[1]|grid.locs[,2]>ylim[2])
          #   if(length(rem)>0){
          #     grid.locs=grid.locs[-rem,]
          #   }
          #   dtmp.tmp=e2dist(grid.locs,X)
          #   lamd.tmp=lam0*exp(-dtmp.tmp*dtmp.tmp/(2*sigma*sigma))
          #   pd.tmp=1-exp(-lamd.tmp)
          #   npoints=nrow(grid.locs)
          #   grid.lik=rep(NA,nrow=npoints)
          #   for(j in 1:npoints){
          #     grid.lik[j]=exp(sum(dbinom(y.cand[i,,],1,pd.tmp[j,],log=TRUE)))
          #   }
          #   grid.probs=grid.lik/sum(grid.lik)
          #   choose=sample(1:npoints,1,prob=grid.probs)
          #   s.cand[i,]=grid.locs[choose,]
          #   dtmp[i,]=dtmp.tmp[choose,]
          #   lamd.cand[swapped[i],]=lamd.tmp[choose,]
          #   pd.cand[swapped[i],]=pd.tmp[choose,]
          # }
          # image(seq(meanS[1]-s.lim/2,meanS[1]+s.lim/2,res),
          #       seq(meanS[2]-s.lim/2,meanS[2]+s.lim/2,res),matrix(grid.probs,nrow=sqrt(npoints)))
          # points(X)
          # points(X[ which(rowSums(y.cand[i,,])>0),1],X[which(rowSums(y.cand[i,,])>0),2],pch=4)
          
          
          #calcluate ll.unk and ll.unk.cand  only one jk affected. Unless we update s
          # thisjk=which(y.unk[l,,]==1,arr.ind=TRUE)
          # for(j in thisjk[1]){
          #   for(k in thisjk[2]){
          #     # for(j in 1:J){
          #     #   for(k in 1:K){
          #     latentID=which(y.unk[,j,k]==1)
          #     if(length(latentID)==1){
          #       #ll.unk
          #       p1=pd[unk.guys,j]*z[unk.guys]
          #       p2=p1/sum(p1)
          #       trueID=ID[latentID]-n
          #       counts=rep(0,length(unk.guys))
          #       for(i in 1:length(trueID)){
          #         counts[trueID[i]]=counts[trueID[i]]+1
          #       }
          #       ll.unk[j,k]=dmultinom(counts,njk[j,k],p2,log=TRUE)
          #       trueID=newID[latentID]-n
          #       counts=rep(0,length(unk.guys))
          #       for(i in 1:length(trueID)){
          #         counts[trueID[i]]=counts[trueID[i]]+1
          #       }
          #       ll.unk.cand[j,k]=dmultinom(counts,njk[j,k],p2,log=TRUE)
          #     }else{
          #       #ll.unk
          #       p1=pd[unk.guys,j]*z[unk.guys]
          #       p2=p1/sum(p1)
          #       trueID=ID[latentID]-n
          #       trueID=trueID[-which(trueID==(ID[l]-n))]
          #       thisp=p2[ID[l]-n]/sum(p2[-trueID])#works even if duplicates in trueID
          #       ll.unk[j,k]=dbinom(1,1,thisp,log=TRUE)
          #       #ll.unk.cand
          #       trueID=newID[latentID]-n
          #       trueID=trueID[-which(trueID==(newID[l]-n))]
          #       thisp=p2[newID[l]-n]/sum(p2[-trueID])
          #       ll.unk[j,k]=dbinom(1,1,thisp,log=TRUE)
          #       ll.unk.cand[j,k]=dbinom(1,1,thisp,log=TRUE)
          #     }
          #   }
          # }
          # thisjk=which(y.unk[l,,]==1,arr.ind=TRUE)
          # for(j in thisjk[1]){
          #   for(k in thisjk[2]){
          #     # for(j in 1:J){
          #     #   for(k in 1:K){
          #     latentID=which(y.unk[,j,k]==1)
          #     #ll.unk
          #     p1=pd[unk.guys,j]*z[unk.guys]
          #     p2=p1/sum(p1)
          #     trueID=ID[latentID]-n
          #     counts=rep(0,length(unk.guys))
          #     for(i in 1:length(trueID)){
          #       counts[trueID[i]]=counts[trueID[i]]+1
          #     }
          #     ll.unk[j,k]=dmultinom(counts,njk[j,k],p2,log=TRUE)
          #     #ll.unk.cand
          #     p1=pd[unk.guys,j]*z[unk.guys]
          #     p2=p1/sum(p1)
          #     trueID=newID[latentID]-n
          #     counts=rep(0,length(unk.guys))
          #     for(i in 1:length(trueID)){
          #       counts[trueID[i]]=counts[trueID[i]]+1
          #     }
          #     ll.unk.cand[j,k]=dmultinom(counts,njk[j,k],p2,log=TRUE)
          #   }
          # }
          ll.y.cand[swapped,,]=dbinom(y.cand,1,pd[swapped,],log=TRUE)
          # ll.y.cand[swapped,,]=dbinom(y.cand,1,pd.cand[swapped,],log=TRUE)
          
          #Check for errors
          # for(j in 1:length(newID)){
          #   focal=ID[j]
          #   thiscluster=which(newID==focal)
          #   if(length(thiscluster)>1){
          #     for(k in 1:length(thiscluster))
          #       if(any(constraints[thiscluster,thiscluster]==0)){
          #         stop("error")
          #       }
          #   }
          # }
          # if(runif(1)<exp(ll.unk.cand[thisjk[1],thisjk[2]]-ll.unk[thisjk[1],thisjk[2]])*(jump.back/jump.probability)){
          
          # if(runif(1)<exp((sum(ll.y.cand[swapped,,])+sum(ll.unk.cand))-(sum(ll.y[swapped,,])+sum(ll.unk)))*(jump.back/jump.probability)){
          if(runif(1)<exp(sum(ll.y.cand[swapped,,])-sum(ll.y[swapped,,]))*(jump.back/jump.probability)){
            
            # if(runif(1)<exp((sum(ll.y.cand[swapped,,])+ll.unk.cand[thisjk[1],thisjk[2]])-(sum(ll.y[swapped,,])+ll.unk[thisjk[1],thisjk[2]]))*(jump.back/jump.probability)){
            y.true[swapped,,]=y.cand
            # s[swapped,]=s.cand
            # D[swapped,]=dtmp
            # lamd[swapped,]=lamd.cand[swapped,]
            # pd[swapped,]=pd.cand[swapped,]
            ll.y[swapped,,]=ll.y.cand[swapped,,]
            ID=newID
            known.vector[swapped]=1*(rowSums(y.cand)>0)
          }
        }
      }
    }else{###Poisson
      dv<-  sqrt( (s[ID[l],1]- s[(n+1):M,1])^2 + (s[ID[l],2] - s[(n+1):M,2])^2 )
      possible<- which(dv < swap.tol)+n
      possible=possible[-which(possible==ID[l])]
      possible=possible[z[possible]==1]
      if(length(possible)>0){#Check to see if constraints match and binomial histories are compatible
        thiscluster=which(ID==ID[l])
        legal=rep(TRUE,length(possible))
        #Check to see if you can swap into these clusters
        for(i in 1:length(possible)){
          check=which(ID==possible[i])#Who else is currently assigned this possible new ID?
          if(length(check)>0){#if false, no ID assigned to this guy and legal stays true
            for(k in 1:length(thiscluster)){#loop through guys in focal cluster
              for(j in 1:length(check)){#check against guys in possible cluster
                if(constraints[thiscluster[k],check[j]]==0){#if any members of the cluster are inconsistent, illegal move
                  legal[i]=FALSE
                }
              }
            }
          }
        }
        possible=possible[legal]
        if(length(possible)>0){#Can update
          jump.probability<- 1/length(possible) # h(theta*|theta)
          newID=ID
          if(length(possible)>1){
            newID[l] <-  sample( possible, 1)
          }else{
            newID[l]=possible
          }
          trash<-  sqrt( (s[newID[l],1]- s[(n+1):M,1])^2 + (s[newID[l],2] - s[(n+1):M,2])^2 )
          trash<-   which(dv < swap.tol)+n
          trash=trash[-which(trash==newID[l])]
          trash=trash[z[trash]==1]
          legal=rep(TRUE,length(trash))
          backcluster=which(newID==newID[l])#which guys are in the new ID cluster?
          # Check to see if you can swap into these clusters
          for(i in 1:length(trash)){
            check=which(newID==trash[i])
            for(k in 1:length(backcluster)){#loop through guys in back cluster
              if(length(check)>0){#if false, no ID assigned to this back guy and legal stays true
                for(j in 1:length(check)){#check against back guys in proposed cluster
                  if(constraints[backcluster[k],check[j]]==0){#if any members of the cluster are inconsistent, illegal move
                    legal[i]=FALSE
                  }
                }
              }
            }
          }
          trash=trash[legal]
          jump.back<-  1/length(trash)
          swapped=c(ID[l],newID[l])#order swap.out then swap.in
          cluster1guys=which(newID==swapped[1])
          cluster2guys=which(newID==swapped[2])
          y.cand=array(0,dim=c(2,J,K))
          if(length(cluster1guys)>0){
            if(length(cluster1guys)>1){
              y.cand[1,,]=colSums(y.unk[cluster1guys,,])
            }else{
              y.cand[1,,]=y.unk[cluster1guys,,]
            }
          }
          if(length(cluster2guys)>0){
            if(length(cluster2guys)>1){
              y.cand[2,,]=colSums(y.unk[cluster2guys,,])
            }else{
              y.cand[2,,]=y.unk[cluster2guys,,]
            }
          }
          #Propose new S from full conditional based on new ID
          # s.cand=matrix(NA,nrow=2,ncol=2)
          # lamd.cand=lamd
          # dtmp=matrix(NA,nrow=2,ncol=J)
          # for(i in 1:2){
          #   #find mean cluster location to center window around
          #   traps=which(rowSums(y.cand[i,,])>0)
          #   if(length(traps)==0){#if empty cluster, center around current s
          #     meanS=s[swapped[i],]
          #   }else{#cluster not empty
          #     currS=X[traps,]
          #     if(!is.null(dim(currS))){#if more than one location
          #       meanS=colMeans(currS)
          #     }else{#only 1 location
          #       meanS=currS
          #     }
          #   }
          #   xlim2=c(meanS[1]-s.lim/2,meanS[1]+s.lim/2)
          #   ylim2=c(meanS[2]-s.lim/2,meanS[2]+s.lim/2)
          #   grid.locs=as.matrix(expand.grid(seq(xlim2[1],xlim2[2],res),seq(ylim2[1],ylim2[2],res)))
          #   #Check for any off state space
          #   rem=which(grid.locs[,1]<xlim[1]|grid.locs[,1]>xlim[2]|grid.locs[,2]<ylim[1]|grid.locs[,2]>ylim[2])
          #   if(length(rem)>0){
          #     grid.locs=grid.locs[-rem,]
          #   }
          #   dtmp.tmp=e2dist(grid.locs,X)
          #   lamd.tmp=lam0*exp(-dtmp.tmp*dtmp.tmp/(2*sigma*sigma))
          #   npoints=nrow(grid.locs)
          #   grid.lik=rep(NA,nrow=npoints)
          #   for(j in 1:npoints){
          #     grid.lik[j]=exp(sum(dpois(y.cand[i,,],lamd.tmp[j,],log=TRUE)))
          #   }
          #   grid.probs=grid.lik/sum(grid.lik)
          #   # choose=sample(1:npoints,1,prob=grid.probs)
          #   choose=which(grid.probs==max(grid.probs))
          #   if(length(choose>1)){
          #     choose=choose[1]
          #   }
          #   s.cand[i,]=grid.locs[choose,]
          #   dtmp[i,]=dtmp.tmp[choose,]
          #   lamd.cand[swapped[i],]=lamd.tmp[choose,]
          #   # image(unique(grid.locs[,1]),unique(grid.locs[,2]),matrix(grid.probs,nrow=length(unique(grid.locs[,1]))))
          #   # points(X)
          #   # points(X[ which(rowSums(y.cand[i,,])>0),1],X[which(rowSums(y.cand[i,,])>0),2],pch=4,cex=2)
          #   # points(s.cand[i,1],s.cand[i,2])
          # }
          # thisjk=which(y.unk[l,,]==1,arr.ind=TRUE)
          # for(j in thisjk[1]){
          #   for(k in thisjk[2]){
          # # for(j in 1:J){
          # #   for(k in 1:K){
          #     if(njk[j,k]>0){
          #       latentID=which(y.unk[,j,k]==1)
          #       #if only 1 sample in njk, current and new cluster treated the same
          #       if(length(latentID)==1){ #only 1 sample in njk
          #         #ll.unk
          #         p1=lamd[unk.guys,j]*z[unk.guys]
          #         p1=p1[swapped-n]
          #         p2=p1/sum(p1)
          #         # trueID=ID[latentID]-n
          #         # counts=rep(0,length(unk.guys))
          #         # counts[trueID]=1
          #         # ll.unk[j,k]=dmultinom(counts,1,p2,log=TRUE)
          #         ll.unk[j,k]=dmultinom(c(1,0),1,p2,log=TRUE)
          #         #ll.unk.cand
          #         p1=lamd[unk.guys,j]*z[unk.guys]
          #         p1=p1[swapped-n]
          #         p2=p1/sum(p1)
          #         # trueID=newID[latentID]-n
          #         # counts=rep(0,length(unk.guys))
          #         # counts[trueID]=1
          #         # ll.unk.cand[j,k]=dmultinom(counts,1,p2,log=TRUE)
          #         ll.unk.cand[j,k]=dmultinom(c(0,1),1,p2,log=TRUE)
          #       }else{#nij > 1
          #         #ll.unk
          #         trueID=newID[latentID]-n
          #         if(length((ID[l]-n)==trueID)>1){#more than 1 sample of focal guy in cluster
          #           trueID=trueID[-which(trueID==(ID[l]-n))]
          #           if(length(trueID)>0){#someone else in cluster with focal
          #             thisp=p2[ID[l]-n]/sum(p2[-trueID])
          #             ll.unk[j,k]=dbinom(1,1,thisp,log=TRUE)
          #           }else{#focal guy only guy in cluster, but >1 sample
          #             thisp=p2[ID[l]-n]/sum(p2)
          #             ll.unk[j,k]=dbinom(1,1,thisp,log=TRUE)
          #           }
          #         }else{#focal guy only in cluster 1 time. others in cluster with him
          #           trueID=trueID[-which(trueID==(ID[l]-n))]
          #           thisp=p2[ID[l]-n]/sum(p2[-trueID])
          #           ll.unk[j,k]=dbinom(1,1,thisp,log=TRUE)
          #         }
          #         #ll.unk.cand
          #         trueID=newID[latentID]-n
          #         if(length((newID[l]-n)==trueID)>1){#more than 1 sample of focal guy in cluster
          #           trueID=trueID[-which(trueID==(newID[l]-n))]
          #           if(length(trueID)>0){#someone else in cluster with focal
          #             thisp=p2[newID[l]-n]/sum(p2[-trueID])
          #             ll.unk.cand[j,k]=dbinom(1,1,thisp,log=TRUE)
          #           }else{#focal guy only guy in cluster, but >1 sample
          #             thisp=p2[newID[l]-n]/sum(p2)
          #             ll.unk.cand[j,k]=dbinom(1,1,thisp,log=TRUE)
          #           }
          #         }else{#focal guy only in cluster 1 time. others in cluster with him
          #           trueID=trueID[-which(trueID==(newID[l]-n))]
          #           thisp=p2[newID[l]-n]/sum(p2[-trueID])
          #           ll.unk.cand[j,k]=dbinom(1,1,thisp,log=TRUE)
          #         }
          #       }
          #     }
          #   }
          # }
          # thisjk=which(y.unk[l,,]>0,arr.ind=TRUE)
          # # for(j in thisjk[1]){
          # #   for(k in thisjk[2]){
          # # for(j in 1:J){
          # #   for(k in 1:K){
          # llunksum=llunkcandsum=0
          # for(i in 1:nrow(thisjk)){
          #   j=thisjk[i,1]
          #   k=thisjk[i,2]
          #   latentID=which(y.unk[,j,k]>0)
          #   #ll.unk
          #   p1=lamd[unk.guys,j]*z[unk.guys]
          #   p2=p1/sum(p1)
          #   trueID=ID[latentID]-n
          #   counts=rep(0,length(unk.guys))
          #   for(i in 1:length(trueID)){
          #     counts[trueID[i]]=counts[trueID[i]]+1
          #   }
          #   ll.unk[j,k]=dmultinom(counts,njk[j,k],p2,log=TRUE)
          #   llunksum=llunksum+ll.unk[j,k]
          #   #ll.unk.cand
          #   p1=lamd.cand[unk.guys,j]*z[unk.guys]
          #   p2=p1/sum(p1)
          #   trueID=newID[latentID]-n
          #   counts=rep(0,length(unk.guys))
          #   for(i in 1:length(trueID)){
          #     counts[trueID[i]]=counts[trueID[i]]+1
          #   }
          #   ll.unk.cand[j,k]=dmultinom(counts,njk[j,k],p2,log=TRUE)
          #   llunkcandsum=llunkcandsum+ll.unk.cand[j,k]
          # }
          
          ll.y.cand[swapped,,]=dpois(y.cand,lamd[swapped,],log=TRUE)
          # print(llunkcandsum-llunksum)
          # print(sum(ll.y.cand[swapped,,])-sum(ll.y[swapped,,]))
          
          if(runif(1)<exp((sum(ll.y.cand[swapped,,]))-(sum(ll.y[swapped,,])))*(jump.back/jump.probability)){
            # if(runif(1)<exp((sum(ll.y.cand[swapped,,])+sum(ll.unk.cand))-(sum(ll.y[swapped,,])+sum(ll.unk)))*(jump.back/jump.probability)){
            
            # if(runif(1)<exp((sum(ll.y.cand[swapped,,])+llunkcandsum)-(sum(ll.y[swapped,,])+llunksum))*(jump.back/jump.probability)){
            y.true[swapped,,]=y.cand
            # s[swapped,]=s.cand
            # D[swapped,]=dtmp
            # lamd[swapped,]=lamd.cand[swapped,]
            ll.y[swapped,,]=ll.y.cand[swapped,,]
            ID=newID
            known.vector[swapped]=1*(rowSums(y.cand)>0)
          }
        }
      }
    }
  }
}