setwd("D:/supercomputer!/phenoSMR")
source("sim.conSMR.ID.df.R")
source("mcmc.conSMR.ID.df.R")
library(coda)
N=100
n.marked=40
lam0=c(0.2,0.2) #Enter same number of detection function parameters as nlevels[i]
sigma=c(0.75,0.5) #same number of lam0 and sigma parameters
K=20 #occasions
buff=3 #state space buffer
X<- expand.grid(3:11,3:11) #trapping array
pMarkID=c(1,1) #probability of observing marked status of marked and unmarked individuals
pID=1 #Probability marked individuals are identified
ncat=3  #number of ID categories
gamma=IDcovs=vector("list",ncat) #population frequencies of each category level. Assume equal here.
nlevels=rep(2,ncat) #number of levels per IDcat
for(i in 1:ncat){
  gamma[[i]]=rep(1/nlevels[i],nlevels[i])
  IDcovs[[i]]=1:nlevels[i]
}
pIDcat=rep(1,ncat)#category observation probabilities
tlocs=0 #telemetry locs/marked individual
obstype="poisson" #observation model, count or presence/absence?
marktype="premarked" #premarked or natural ID (marked individuals must be captured)?
data=sim.conCatSMR.df(N=N,n.marked=n.marked,lam0=lam0,sigma=sigma,K=K,X=X,buff=buff,obstype=obstype,ncat=ncat,
           pIDcat=pIDcat,gamma=gamma,IDcovs=IDcovs,pMarkID=pMarkID,tlocs=tlocs,pID=pID,marktype=marktype)

inits=list(lam0=lam0,sigma=sigma,gamma=gamma,psi=0.7)#start at simulated values
proppars=list(lam0=c(0.04,0.08),sigma=c(0.1,0.07),s=0.5,st=0.08)#proppar for each lam0 and sigma

M=275
storeLatent=TRUE
storeGamma=FALSE
niter=1500
nburn=0
nthin=1
IDup="Gibbs"
out=mcmc.conCatSMR.df(data,niter=niter,nburn=nburn, nthin=nthin, M = M, inits=inits,obstype=obstype,
           proppars=proppars,storeLatent=TRUE,storeGamma=TRUE,IDup=IDup)

plot(mcmc(out$out))


1-rejectionRate(mcmc(out$out)) #shoot for 0.2 - 0.4 for lam0 and sigma. If too low, raise proppar. If too high, lower proppar.
1-rejectionRate(mcmc(out$sxout)) #activity center acceptance in x dimension. Shoot for min of 0.2
sum(rowSums(data$y.sight[(n.marked+1):N,,])>0) #true number of n.um


